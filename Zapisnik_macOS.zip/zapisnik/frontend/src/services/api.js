const BASE = '/api/contacts';

async function r(url, opts = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    const err = new Error(body.error || res.statusText);
    if (body.field) err.field = body.field;
    throw err;
  }
  return res.json().catch(() => ({}));
}

export const getAll      = (groupId) => r(`${BASE}${groupId ? `?group_id=${groupId}` : ''}`);
export const getOne      = (id)      => r(`${BASE}/${id}`);
export const create      = (data)    => r(BASE,           { method: 'POST', body: JSON.stringify(data) });
export const update      = (id, d)   => r(`${BASE}/${id}`, { method: 'PUT',  body: JSON.stringify(d) });
export const remove      = (id)      => r(`${BASE}/${id}`, { method: 'DELETE' });
export const search      = (q)       => r(`${BASE}/search?q=${encodeURIComponent(q)}`);
export const backup      = ()        => { window.location.href = `${BASE}/backup`; };
export const restore     = (data, replace) => r(`${BASE}/restore`, { method: 'POST', body: JSON.stringify({ data, replace }) });
export const importData  = (fmt, data) => r(`${BASE}/import/${fmt}`, { method: 'POST', body: JSON.stringify({ data }) });
export const exportData  = (fmt, ids)  => {
  const q = ids && ids.length ? `?ids=${ids.join(',')}` : '';
  window.location.href = `${BASE}/export/${fmt}${q}`;
};
export const getGroups   = ()        => r(`${BASE}/groups`);
export const createGroup = (name)    => r(`${BASE}/groups`, { method: 'POST', body: JSON.stringify({ name }) });
export const updateGroup = (id, name) => r(`${BASE}/groups/${id}`, { method: 'PUT', body: JSON.stringify({ name }) });
export const removeGroup = (id)      => r(`${BASE}/groups/${id}`, { method: 'DELETE' });
