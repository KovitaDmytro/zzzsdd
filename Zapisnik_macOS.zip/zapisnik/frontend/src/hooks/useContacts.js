import { useState, useEffect, useCallback, useRef } from 'react';
import * as api from '../services/api.js';

export function useContacts() {
  const [contacts,    setContacts]    = useState([]);
  const [loading,     setLoading]     = useState(false);
  const [query,       setQuery]       = useState('');
  const [activeGroup, setActiveGroup] = useState(null);

  // FIX БАГ#2: абортуємо попередній запит при новому (race condition)
  const abortRef = useRef(null);

  const load = useCallback(async (q = '', groupId = null) => {
    if (abortRef.current) abortRef.current = false;
    const token = {};
    abortRef.current = token;

    setLoading(true);
    try {
      let result;
      if (q.trim()) {
        const results = await api.search(q);
        if (token !== abortRef.current) return; // застарілий запит
        if (groupId) {
          const groupContacts = await api.getAll(groupId);
          if (token !== abortRef.current) return;
          const groupIds = new Set(groupContacts.map(c => c.id));
          result = results.filter(c => groupIds.has(c.id));
        } else {
          result = results;
        }
      } else {
        result = await api.getAll(groupId);
        if (token !== abortRef.current) return;
      }
      setContacts(result);
    } catch(e) { console.error(e); }
    finally { if (token === abortRef.current) setLoading(false); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(query, activeGroup), 300);
    return () => clearTimeout(t);
  }, [query, activeGroup, load]);

  return {
    contacts, loading, query, setQuery, activeGroup, setActiveGroup,
    add:    async d     => { await api.create(d);       load(query, activeGroup); },
    edit:   async(id,d) => { await api.update(id, d);   load(query, activeGroup); },
    del:    async id    => { await api.remove(id);       load(query, activeGroup); },
    reload: ()          =>   load(query, activeGroup),
  };
}
