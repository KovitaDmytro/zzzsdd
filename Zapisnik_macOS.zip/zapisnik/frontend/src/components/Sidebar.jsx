import { useState } from 'react';

export default function Sidebar({
  theme:t, dark, toggleTheme, lang, toggleLang, L,
  count, selected, groups, activeGroup,
  onNew, onExport, onImport, onBackup, onRestore,
  onSelectGroup, onNewGroup, onEditGroup, onDeleteGroup,
}) {
  const [hovGroup, setHovGroup] = useState(null);
  const [toolsOpen, setToolsOpen] = useState(false);
  const sel = selected.size > 0 ? ` (${selected.size})` : '';

  const sb = t.sidebarText;
  const sbm = t.sidebarTextMuted;
  const sba = t.sidebarActive;
  const sbh = t.sidebarHover;

  const NavBtn = ({ icon, label, onClick, danger, active }) => (
    <button onClick={onClick} style={{
      display:'flex', alignItems:'center', gap:9,
      width:'100%', padding:'7px 12px', borderRadius:6,
      background: active ? sba : 'transparent',
      border:'none', cursor:'pointer',
      color: danger ? '#FCA5A5' : active ? '#FFFFFF' : sb,
      fontSize:13, fontWeight: active ? 600 : 400, textAlign:'left', transition:'background .12s',
    }}
    onMouseEnter={e=>{ if(!active) e.currentTarget.style.background=danger?'rgba(248,113,113,.12)':sbh; }}
    onMouseLeave={e=>{ e.currentTarget.style.background=active?sba:'transparent'; }}>
      <span style={{width:16,textAlign:'center',flexShrink:0,opacity:.7}}>{icon}</span>
      <span style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{label}</span>
    </button>
  );

  const Divider = () => <div style={{height:'1px',background:t.sidebarBorder,margin:'4px 0'}}/>;
  const SecLabel = ({txt}) => <div style={{fontSize:10,fontWeight:600,color:t.sidebarSection,textTransform:'uppercase',letterSpacing:'.1em',padding:'10px 12px 3px'}}>{txt}</div>;

  return (
    <aside style={{width:220,flexShrink:0,background:t.sidebar,display:'flex',flexDirection:'column',position:'sticky',top:0,height:'100vh',borderRight:`1px solid ${t.sidebarBorder}`,overflowY:'auto'}}>

      {/* App header */}
      <div style={{padding:'16px 14px 12px',borderBottom:`1px solid ${t.sidebarBorder}`}}>
        <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:12}}>
          <div style={{width:30,height:30,borderRadius:7,background:t.accentGrad,display:'flex',alignItems:'center',justifyContent:'center',fontSize:15,flexShrink:0}}>📒</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{color:'#F1F5F9',fontSize:13,fontWeight:600,letterSpacing:'-.01em',lineHeight:1.2}}>{L.appName}</div>
            <div style={{color:sbm,fontSize:10,marginTop:1}}>{L.appSub}</div>
          </div>
        </div>

        {/* Controls row */}
        <div style={{display:'flex',gap:5,marginBottom:12}}>
          <button onClick={toggleLang} title={lang==='ua'?'English':'Українська'} style={{flex:1,background:'rgba(255,255,255,.07)',border:`1px solid ${t.sidebarBorder}`,borderRadius:5,padding:'5px',cursor:'pointer',color:sb,fontSize:11,fontWeight:600,transition:'background .12s'}}
            onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,.12)'}
            onMouseLeave={e=>e.currentTarget.style.background='rgba(255,255,255,.07)'}>
            {lang==='ua'?'EN':'UA'}
          </button>
          <button onClick={toggleTheme} title={dark?'Світла тема':'Темна тема'} style={{flex:1,background:'rgba(255,255,255,.07)',border:`1px solid ${t.sidebarBorder}`,borderRadius:5,padding:'5px',cursor:'pointer',color:sb,fontSize:12,transition:'background .12s'}}
            onMouseEnter={e=>e.currentTarget.style.background='rgba(255,255,255,.12)'}
            onMouseLeave={e=>e.currentTarget.style.background='rgba(255,255,255,.07)'}>
            {dark?'☀️':'🌙'}
          </button>
        </div>

        {/* Contact count */}
        <div style={{padding:'9px 12px',background:'rgba(255,255,255,.05)',borderRadius:7,border:`1px solid ${t.sidebarBorder}`}}>
          <span style={{fontSize:22,fontWeight:700,color:'#F1F5F9',letterSpacing:'-.03em',lineHeight:1}}>{count}</span>
          <span style={{fontSize:11,color:sbm,marginLeft:7}}>{L.contactsCount(count).split(' ').slice(1).join(' ')}</span>
        </div>
      </div>

      {/* New contact button */}
      <div style={{padding:'10px 12px 4px',display:'flex',flexDirection:'column',gap:6}}>
        <button onClick={onNew} style={{display:'flex',alignItems:'center',justifyContent:'center',gap:7,width:'100%',padding:'8px 14px',borderRadius:7,background:t.accentGrad,color:'#fff',border:'none',cursor:'pointer',fontSize:13,fontWeight:600,transition:'opacity .15s'}}
          onMouseEnter={e=>e.currentTarget.style.opacity='.88'}
          onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
          + {L.newContact.replace('＋ ','')}
        </button>
      </div>

      {/* Groups */}
      <nav style={{padding:'0 8px',flex:1}}>
        <SecLabel txt={L.groups}/>
        <NavBtn icon="👥" label={L.allGroupsLabel} onClick={()=>onSelectGroup(null)} active={activeGroup===null}/>

        {(groups||[]).map(g => (
          <div key={g.id} style={{position:'relative',display:'flex',alignItems:'center'}}
            onMouseEnter={()=>setHovGroup(g.id)} onMouseLeave={()=>setHovGroup(null)}>
            <button onClick={()=>onSelectGroup(g.id)} style={{
              display:'flex',alignItems:'center',gap:9,flex:1,
              padding:'7px 12px',borderRadius:6,border:'none',cursor:'pointer',
              background:activeGroup===g.id?sba:'transparent',
              color:activeGroup===g.id?'#FFFFFF':sb,
              fontSize:13,fontWeight:activeGroup===g.id?600:400,textAlign:'left',transition:'background .12s',
            }}
            onMouseEnter={e=>{ if(activeGroup!==g.id) e.currentTarget.style.background=sbh; }}
            onMouseLeave={e=>e.currentTarget.style.background=activeGroup===g.id?sba:'transparent'}>
              <span style={{width:16,textAlign:'center',opacity:.6,flexShrink:0}}>📁</span>
              <span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{g.name}</span>
              <span style={{fontSize:11,color:sbm,marginLeft:4,flexShrink:0}}>{g.contact_count}</span>
            </button>
            {hovGroup===g.id && (
              <div style={{position:'absolute',right:4,display:'flex',gap:2,zIndex:10,background:t.sidebar,borderRadius:5,padding:'1px'}}>
                <button onClick={e=>{e.stopPropagation();onEditGroup(g);}} style={{background:'rgba(255,255,255,.1)',border:'none',borderRadius:4,padding:'3px 6px',cursor:'pointer',color:sb,fontSize:11}}>✏️</button>
                <button onClick={e=>{e.stopPropagation();onDeleteGroup(g);}} style={{background:'rgba(248,113,113,.15)',border:'none',borderRadius:4,padding:'3px 6px',cursor:'pointer',color:'#FCA5A5',fontSize:11}}>🗑️</button>
              </div>
            )}
          </div>
        ))}

        <button onClick={onNewGroup} style={{display:'flex',alignItems:'center',gap:9,width:'100%',padding:'6px 12px',borderRadius:6,background:'transparent',border:`1px dashed rgba(255,255,255,.15)`,cursor:'pointer',color:sbm,fontSize:12,fontWeight:400,marginTop:3,transition:'all .12s'}}
          onMouseEnter={e=>{e.currentTarget.style.borderColor='rgba(255,255,255,.35)';e.currentTarget.style.color=sb;}}
          onMouseLeave={e=>{e.currentTarget.style.borderColor='rgba(255,255,255,.15)';e.currentTarget.style.color=sbm;}}>
          {L.newGroup}
        </button>

        <Divider/>

        {/* Export/Import with explanation */}
        <div style={{padding:'10px 12px 2px',display:'flex',alignItems:'center',gap:5}}>
          <span style={{fontSize:10,fontWeight:600,color:t.sidebarSection,textTransform:'uppercase',letterSpacing:'.1em'}}>{L.export}</span>
        </div>
        <div style={{padding:'0 10px 4px'}}>
          <div style={{fontSize:10,color:t.sidebarTextMuted,lineHeight:1.5,background:'rgba(255,255,255,.04)',borderRadius:5,padding:'5px 8px'}}>{L.exportNote}</div>
        </div>
        <NavBtn icon="📄" label={'XML' + sel}   onClick={()=>onExport('xml')}/>
        <NavBtn icon="📱" label={'vCard' + sel}  onClick={()=>onExport('vcf')}/>
        <Divider/>
        <SecLabel txt={L.import}/>
        <NavBtn icon="📄" label="XML"   onClick={()=>onImport('xml')}/>
        <NavBtn icon="📱" label="vCard" onClick={()=>onImport('vcf')}/>
      </nav>

      {/* Footer tools */}
      <div style={{padding:'4px 8px 12px',borderTop:`1px solid ${t.sidebarBorder}`}}>
        <div style={{padding:'4px 10px 2px'}}>
          <div style={{fontSize:10,color:t.sidebarTextMuted,lineHeight:1.5,background:'rgba(255,255,255,.04)',borderRadius:5,padding:'5px 8px'}}>{L.backupNote}</div>
        </div>
        <NavBtn icon="💾" label={L.backup}  onClick={onBackup}/>
        <NavBtn icon="📂" label={L.restore} onClick={onRestore}/>
        <div style={{marginTop:8,padding:'8px 10px',background:'rgba(255,255,255,.04)',borderRadius:7,border:`1px solid ${t.sidebarBorder}`}}>
          <div style={{fontSize:10,color:t.sidebarSection,lineHeight:1.6}}>{L.footer}</div>
        </div>
      </div>
    </aside>
  );
}
