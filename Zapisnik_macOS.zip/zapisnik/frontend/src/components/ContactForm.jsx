import { useState } from 'react';

const empty = () => ({first_name:'',last_name:'',nickname:'',company:'',birthday:'',notes:'',phones:[{phone:'',label:'mobile'}],emails:[{email:'',label:'personal'}],custom_fields:[],groups:[]});
const fromC = c => ({
  first_name:c.first_name||'', last_name:c.last_name||'',
  nickname:c.nickname||'', company:c.company||'',
  birthday:c.birthday||'', notes:c.notes||'',
  phones:c.phones?.length?c.phones.map(p=>({phone:p.phone,label:p.label})):[{phone:'',label:'mobile'}],
  emails:c.emails?.length?c.emails.map(e=>({email:e.email,label:e.label})):[{email:'',label:'personal'}],
  custom_fields:(c.custom_fields||[]).map(f=>({field_name:f.field_name,field_value:f.field_value})),
  groups:(c.groups||[]).map(g=>g.id),
});

// BUG FIX: added email format validation
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function ContactForm({ theme:t, L, contact, onSave, onCancel, groups=[] }) {
  // contact може бути: null (новий), об'єкт з id (редагування)
  const initState = () => {
    if (!contact) return empty();
    return fromC(contact);
  };
  const [f,setF]           = useState(initState);
  const [saving,setSaving] = useState(false);
  const [err,setErr]       = useState('');

  const set  = (k,v)     => setF(x=>({...x,[k]:v}));
  const setA = (a,i,k,v) => setF(x=>({...x,[a]:x[a].map((r,j)=>j===i?{...r,[k]:v}:r)}));
  const addA = (a,item)  => setF(x=>({...x,[a]:[...x[a],item]}));
  const rmA  = (a,i)     => setF(x=>({...x,[a]:x[a].filter((_,j)=>j!==i)}));
  const toggleGroup = gid => setF(x=>({...x, groups: x.groups.includes(gid) ? x.groups.filter(id=>id!==gid) : [...x.groups,gid]}));

  const labelOpts = key => key==='phones'
    ? ['mobile','home','work','other'].map(o=>({v:o,l:L[o]}))
    : ['personal','work','other'].map(o=>({v:o,l:L[o]}));

  const submit = async e => {
    e.preventDefault();
    if (!f.first_name.trim()) { setErr(L.firstNameReq); return; }
    if (!f.last_name.trim())  { setErr(L.lastNameReq); return; }
    // BUG FIX: validate emails before saving
    const invalidEmail = f.emails.find(e => e.email.trim() && !isValidEmail(e.email.trim()));
    if (invalidEmail) { setErr(`Невірний формат email: "${invalidEmail.email}"`); return; }
    setSaving(true); setErr('');
    try { await onSave(f); }
    catch(ex) { setErr(ex.message); setSaving(false); }
  };

  const inp = {fontFamily:'inherit',fontSize:13,border:`1px solid ${t.inpBorder}`,borderRadius:7,padding:'8px 12px',boxSizing:'border-box',outline:'none',background:t.inpBg,color:t.text,width:'100%',transition:'border-color .15s'};
  const lbl = {display:'block',fontSize:11,fontWeight:600,color:t.textMuted,textTransform:'uppercase',letterSpacing:'.08em',marginBottom:4};
  const grp = {border:`1px solid ${t.border}`,borderRadius:8,padding:12,display:'flex',flexDirection:'column',gap:8,background:t.dark?'rgba(255,255,255,.02)':'rgba(0,0,0,.01)'};
  const addBtn = {background:t.accentSoft,color:t.accent,border:`1px solid ${t.accent}22`,fontSize:12,fontWeight:600,padding:'4px 11px',borderRadius:6,cursor:'pointer'};
  const rmBtn  = {background:t.dangerSoft,color:t.danger,border:'none',padding:'6px 10px',borderRadius:6,cursor:'pointer',flexShrink:0,fontSize:13};

  return (
    <div style={{position:'fixed',inset:0,background:t.overlay,display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:16,backdropFilter:'blur(3px)'}}>
      <div style={{background:t.bgCard,color:t.text,borderRadius:12,width:'100%',maxWidth:520,maxHeight:'92vh',display:'flex',flexDirection:'column',boxShadow:t.shadowLg,border:`1px solid ${t.glassBorder}`,animation:'fin .18s ease'}}>

        {/* Header */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 20px',borderBottom:`1px solid ${t.border}`,flexShrink:0}}>
          <div>
            <h2 style={{fontSize:16,fontWeight:600,color:t.text,margin:0}}>{contact?L.editContactTitle:L.newContactTitle}</h2>
            <p style={{fontSize:12,color:t.textMuted,margin:'2px 0 0'}}>{L.formSub}</p>
          </div>
          <button onClick={onCancel} style={{background:'transparent',border:`1px solid ${t.border}`,borderRadius:7,padding:'6px 10px',cursor:'pointer',color:t.textMuted,fontSize:13}}>✕</button>
        </div>

        <form onSubmit={submit} style={{padding:'16px 20px 20px',overflowY:'auto',display:'flex',flexDirection:'column',gap:12}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            <div>
              <label style={lbl}>{L.firstName} *</label>
              <input value={f.first_name} onChange={e=>set('first_name',e.target.value)} placeholder="Іван / Ivan"
                style={{...inp,borderColor:err&&!f.first_name.trim()?t.danger:t.inpBorder}} autoFocus
                onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=err&&!f.first_name.trim()?t.danger:t.inpBorder}/>
            </div>
            <div>
              <label style={lbl}>{L.lastName} *</label>
              <input value={f.last_name} onChange={e=>set('last_name',e.target.value)} placeholder="Петренко / Smith"
                style={{...inp,borderColor:err&&!f.last_name.trim()?t.danger:t.inpBorder}}
                onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=err&&!f.last_name.trim()?t.danger:t.inpBorder}/>
            </div>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            <div>
              <label style={lbl}>{L.nickname}</label>
              <input value={f.nickname} onChange={e=>set('nickname',e.target.value)} placeholder="@username"
                style={inp} onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
            </div>
            <div>
              <label style={lbl}>{L.company}</label>
              <input value={f.company} onChange={e=>set('company',e.target.value)} placeholder="Company..."
                style={inp} onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
            </div>
          </div>
          <div>
            <label style={lbl}>{L.birthday}</label>
            <input type="date" value={f.birthday} onChange={e=>set('birthday',e.target.value)}
              style={inp} onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
          </div>

          {/* Phones & Emails */}
          {[
            {key:'phones', title:`📞 ${L.phones}`, em:{phone:'',label:'mobile'}},
            {key:'emails', title:`✉️ ${L.emails}`,  em:{email:'',label:'personal'}},
          ].map(({key,title,em})=>(
            <div key={key} style={grp}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <span style={{fontSize:12,fontWeight:600,color:t.textSub}}>{title}</span>
                <button type="button" onClick={()=>addA(key,em)} style={addBtn}>{L.addBtn}</button>
              </div>
              {f[key].map((row,i)=>(
                <div key={i} style={{display:'flex',gap:7,alignItems:'center'}}>
                  <input
                    type={key==='emails'?'email':'text'}
                    value={row[key==='phones'?'phone':'email']}
                    onChange={e=>setA(key,i,key==='phones'?'phone':'email',e.target.value)}
                    placeholder={key==='phones'?'+380...':'email@...'}
                    style={{...inp,flex:2}}
                    onFocus={e=>e.target.style.borderColor=t.accent}
                    onBlur={e=>e.target.style.borderColor=t.inpBorder}
                  />
                  <select value={row.label} onChange={e=>setA(key,i,'label',e.target.value)} style={{...inp,flex:1,cursor:'pointer'}}>
                    {labelOpts(key).map(o=><option key={o.v} value={o.v}>{o.l}</option>)}
                  </select>
                  {f[key].length>1&&<button type="button" onClick={()=>rmA(key,i)} style={rmBtn}>✕</button>}
                </div>
              ))}
            </div>
          ))}

          {/* Groups */}
          {groups.length > 0 && (
            <div style={grp}>
              <span style={{fontSize:12,fontWeight:600,color:t.textSub}}>📁 {L.groupsLabel}</span>
              <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                {groups.map(g => {
                  const active = f.groups.includes(g.id);
                  return (
                    <button key={g.id} type="button" onClick={()=>toggleGroup(g.id)} style={{
                      padding:'4px 12px',borderRadius:20,fontSize:12,fontWeight:500,cursor:'pointer',
                      border:`1px solid ${active?t.accent:t.border}`,
                      background:active?t.accentSoft:'transparent',
                      color:active?t.accent:t.textMuted,transition:'all .12s',
                    }}>{g.name}</button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Custom fields */}
          <div style={grp}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontSize:12,fontWeight:600,color:t.textSub}}>⚙️ {L.customFields}</span>
              <button type="button" onClick={()=>addA('custom_fields',{field_name:'',field_value:''})} style={addBtn}>{L.addBtn}</button>
            </div>
            {f.custom_fields.map((cf,i)=>(
              <div key={i} style={{display:'flex',gap:7,alignItems:'center'}}>
                <input value={cf.field_name}  onChange={e=>setA('custom_fields',i,'field_name',e.target.value)}  placeholder={L.fieldName}
                  style={{...inp,flex:1}} onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
                <input value={cf.field_value} onChange={e=>setA('custom_fields',i,'field_value',e.target.value)} placeholder={L.fieldValue}
                  style={{...inp,flex:2}} onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
                <button type="button" onClick={()=>rmA('custom_fields',i)} style={rmBtn}>✕</button>
              </div>
            ))}
          </div>

          <div>
            <label style={lbl}>{L.notes}</label>
            <textarea value={f.notes} onChange={e=>set('notes',e.target.value)} placeholder={L.notesPlaceholder}
              style={{...inp,minHeight:64,resize:'vertical'}}
              onFocus={e=>e.target.style.borderColor=t.accent} onBlur={e=>e.target.style.borderColor=t.inpBorder}/>
          </div>

          {err&&<div style={{background:t.dangerSoft,color:t.danger,padding:'9px 13px',borderRadius:7,fontSize:13,fontWeight:500,border:`1px solid ${t.danger}33`}}>{err}</div>}

          <div style={{display:'flex',gap:8,justifyContent:'flex-end',paddingTop:2}}>
            <button type="button" onClick={onCancel} style={{background:'transparent',color:t.textSub,border:`1px solid ${t.border}`,borderRadius:7,padding:'8px 18px',cursor:'pointer',fontSize:13}}>{L.cancel}</button>
            <button type="submit" disabled={saving} style={{background:t.accentGrad,color:'#fff',border:'none',borderRadius:7,padding:'8px 22px',fontWeight:600,cursor:'pointer',fontSize:13,opacity:saving?.6:1}}>
              {saving?L.saving:L.save}
            </button>
          </div>
        </form>
        <style>{`@keyframes fin{from{opacity:0;transform:scale(.97) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}`}</style>
      </div>
    </div>
  );
}
