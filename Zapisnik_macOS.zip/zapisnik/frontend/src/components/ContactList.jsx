import { avatarPalette, initials } from '../styles.js';

export default function ContactList({ theme:t, L, contacts, loading, selected, query, onSelect, onDetail, onEdit, onDelete, onNew }) {
  if (loading) return (
    <div style={{display:'flex',flexDirection:'column',gap:1}}>
      {[1,2,3,4,5].map(i=>(
        <div key={i} style={{height:56,borderRadius:8,background:t.bgCard,border:`1px solid ${t.border}`,animation:`pulse 1.6s ease ${i*.1}s infinite`,marginBottom:1}}/>
      ))}
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}`}</style>
    </div>
  );

  if (!contacts.length) return (
    <div style={{textAlign:'center',padding:'72px 0',color:t.textMuted}}>
      <div style={{fontSize:40,marginBottom:12,opacity:.25}}>📭</div>
      <div style={{fontSize:15,fontWeight:600,color:t.textSub,marginBottom:6}}>{query?L.noResults:L.emptyTitle}</div>
      <div style={{fontSize:13,marginBottom:22}}>{query?L.noResultsSub(query):L.emptySub}</div>
      {!query && <button onClick={onNew} style={{background:t.accentGrad,color:'#fff',border:'none',borderRadius:7,padding:'9px 24px',fontWeight:600,cursor:'pointer',fontSize:13}}>{L.newContact}</button>}
    </div>
  );

  return (
    <div style={{display:'flex',flexDirection:'column',gap:1}}>
      {contacts.map((c, idx) => {
        const {bg} = avatarPalette(c.first_name);
        const sel  = selected.has(c.id);
        return (
          <div key={c.id} className="contact-row"
            style={{
              display:'flex',alignItems:'center',gap:12,padding:'10px 14px',
              borderRadius:8,
              background:sel ? t.accentSoft : t.bgCard,
              color:t.text,
              border:`1px solid ${sel ? t.accent+'55' : t.border}`,
              transition:'all .12s',
              animationDelay:`${idx*.02}s`,
            }}>

            {/* Чекбокс — окрема зона вибору */}
            <input type="checkbox" checked={sel} onChange={()=>onSelect(c.id)}
              onClick={e=>e.stopPropagation()}
              style={{width:14,height:14,flexShrink:0,accentColor:t.accent,cursor:'pointer'}}/>

            {/* Аватар + ім'я — клік відкриває деталі */}
            <div onClick={()=>onDetail(c.id)}
              style={{display:'flex',alignItems:'center',gap:12,flex:1,minWidth:0,cursor:'pointer'}}>
              <div style={{width:36,height:36,borderRadius:8,flexShrink:0,background:bg,display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:13,color:'#fff'}}>
                {initials(c)}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontWeight:500,fontSize:14,color:t.text,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                  {c.first_name} {c.last_name||''}
                  {c.nickname&&<span style={{color:t.textMuted,fontWeight:400,fontSize:12,marginLeft:6}}>· {c.nickname}</span>}
                </div>
                <div style={{display:'flex',gap:10,marginTop:1,overflow:'hidden'}}>
                  {c.company    &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap'}}>🏢 {c.company}</span>}
                  {c.phones_str &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap'}}>📞 {c.phones_str.split(',')[0].trim()}</span>}
                  {c.emails_str &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>✉️ {c.emails_str.split(',')[0].trim()}</span>}
                </div>
              </div>
            </div>

            {/* Кнопки дій — ЗАВЖДИ видимі, opacity при спокої */}
            <div style={{display:'flex',gap:4,flexShrink:0}}>
              {[
                {icon:'👁️', label:'Переглянути', cb:e=>{e.stopPropagation();onDetail(c.id);}, d:false},
                {icon:'✏️', label:'Редагувати',  cb:e=>{e.stopPropagation();onEdit(c);}, d:false},
                {icon:'🗑️', label:'Видалити',    cb:e=>{e.stopPropagation();onDelete(c);}, d:true},
              ].map(({icon,label,cb,d},i)=>(
                <button key={i} onClick={cb} title={label}
                  className={`action-btn${d?' action-btn-danger':''}`}
                  style={{
                    background:'transparent',
                    border:`1px solid ${d?'rgba(220,38,38,.2)':t.border}`,
                    borderRadius:6,padding:'5px 8px',cursor:'pointer',fontSize:12,
                    color:d?t.danger:t.textMuted,
                    opacity:.5,
                    transition:'all .12s',
                  }}
                  onMouseEnter={e=>{e.currentTarget.style.background=d?t.dangerSoft:t.hover;e.currentTarget.style.opacity='1';}}
                  onMouseLeave={e=>{e.currentTarget.style.background='transparent';e.currentTarget.style.opacity='.5';}}>
                  {icon}
                </button>
              ))}
            </div>
          </div>
        );
      })}
      <style>{`
        .contact-row { cursor: default; }
        .contact-row:hover { background:${t.bgCardHov} !important; border-color:${t.border} !important; }
        .contact-row:hover .action-btn { opacity: 1 !important; }
        @keyframes rowIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
        .contact-row{animation:rowIn .2s ease both;}
      `}</style>
    </div>
  );
}
