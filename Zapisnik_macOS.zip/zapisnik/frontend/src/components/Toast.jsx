export default function Toast({ msg }) {
  const isError = msg.startsWith('❌');
  return (
    <div style={{
      position:'fixed', bottom:24, right:24,
      background: isError ? '#DC2626' : '#1C2B41',
      color:'#fff', padding:'10px 18px', borderRadius:8,
      fontSize:13, fontWeight:500, zIndex:9999,
      boxShadow:'0 4px 16px rgba(0,0,0,.25)',
      animation:'toastIn .2s ease',
      maxWidth:320, lineHeight:1.5,
    }}>
      {msg}
      <style>{`@keyframes toastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}`}</style>
    </div>
  );
}
