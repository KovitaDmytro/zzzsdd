export default function ContactDetail({ theme:t, L, contact:c, onClose, onEdit }) {
  const row = (label, val) => val ? (
    <div key={label} style={{display:'grid',gridTemplateColumns:'100px 1fr',gap:8,padding:'8px 0',borderBottom:`1px solid ${t.border}`}}>
      <span style={{fontSize:11,color:t.textMuted,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',paddingTop:1}}>{label}</span>
      <span style={{fontSize:13,color:t.text,lineHeight:1.6}}>{val}</span>
    </div>
  ) : null;

  return (
    /* FIX UX#3: overlay поверх контенту, не всередині списку */
    <div style={{
      position:'fixed',inset:0,background:t.overlay,
      display:'flex',alignItems:'flex-start',justifyContent:'flex-end',
      zIndex:500,padding:0,
    }} onClick={onClose}>
      <div
        onClick={e=>e.stopPropagation()}
        style={{
          background:t.bgCard,color:t.text,
          width:'100%',maxWidth:420,height:'100%',
          overflowY:'auto',
          boxShadow:t.shadowLg,
          borderLeft:`1px solid ${t.glassBorder}`,
          animation:'slideIn .2s ease',
          display:'flex',flexDirection:'column',
        }}>

        {/* Header */}
        <div style={{
          display:'flex',alignItems:'flex-start',justifyContent:'space-between',
          padding:'20px 20px 16px',
          borderBottom:`1px solid ${t.border}`,
          flexShrink:0,
        }}>
          <div>
            <h2 style={{fontSize:18,fontWeight:600,color:t.text,margin:'0 0 4px'}}>
              {c.first_name} {c.last_name||''}
            </h2>
            {(c.company||c.nickname)&&
              <div style={{fontSize:12,color:t.textMuted}}>{[c.nickname,c.company].filter(Boolean).join(' · ')}</div>
            }
          </div>
          <div style={{display:'flex',gap:6,flexShrink:0,marginLeft:12}}>
            <button onClick={onEdit} style={{background:t.accentGrad,color:'#fff',border:'none',borderRadius:7,padding:'7px 16px',fontWeight:600,cursor:'pointer',fontSize:12}}>{L.edit}</button>
            <button onClick={onClose} style={{background:'transparent',border:`1px solid ${t.border}`,borderRadius:7,padding:'7px 10px',cursor:'pointer',color:t.textMuted,fontSize:12}}>✕</button>
          </div>
        </div>

        {/* Body */}
        <div style={{padding:'12px 20px 24px',flex:1}}>
          {row(L.born, c.birthday)}
          {(c.phones?.length > 0) && row(L.phonesLabel, c.phones.map(p=>`${p.phone} (${L[p.label]||p.label})`).join('  ·  '))}
          {(c.emails?.length > 0) && row(L.emailLabel,  c.emails.map(e=>e.email).join('  ·  '))}
          {(c.notes?.trim())       && row(L.notesLabel,  c.notes)}
          {(c.groups?.length > 0)  && row(L.groupsDetail, c.groups.map(g=>g.name).join(', '))}
          {(c.custom_fields||[]).map(f=>row(f.field_name, f.field_value))}
        </div>
      </div>
      <style>{`@keyframes slideIn{from{transform:translateX(100%)}to{transform:translateX(0)}}`}</style>
    </div>
  );
}
