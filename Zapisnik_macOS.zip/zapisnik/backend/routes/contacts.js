const router   = require('express').Router();
const ctrl     = require('../controllers/contactController');

// Groups (before /:id to avoid conflict)
router.get('/groups',        ctrl.getGroups);
router.post('/groups',       ctrl.createGroup);
router.put('/groups/:id',    ctrl.updateGroup);
router.delete('/groups/:id', ctrl.removeGroup);

// Export / Import
router.get('/export/xml',  ctrl.exportXml);
router.get('/export/vcf',  ctrl.exportVcf);
router.post('/import/xml', ctrl.importXml);
router.post('/import/vcf', ctrl.importVcf);

// Tools
router.get('/backup',   ctrl.backup);
router.post('/restore', ctrl.restore);

// Search
router.get('/search', ctrl.search);

// Contacts CRUD
router.get('/',     ctrl.getAll);
router.get('/:id',  ctrl.getOne);
router.post('/',    ctrl.create);
router.put('/:id',  ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;
 