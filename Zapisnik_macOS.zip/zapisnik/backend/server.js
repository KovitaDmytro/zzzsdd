const express  = require('express');
const path     = require('path');
const { open } = require('./db/database');
const { migrate } = require('./db/migrate');
const contactsRouter = require('./routes/contacts');

const app  = express();
const PORT = 3001;

open().then(() => {
  migrate();
  app.use(express.json({ limit: '10mb' }));
  app.use(express.static(path.join(__dirname, '../frontend/dist')));
  app.use('/api/contacts', contactsRouter);
  app.get('*', (_req, res) =>
    res.sendFile(path.join(__dirname, '../frontend/dist/index.html'))
  );
  app.listen(PORT, () =>
    console.log('Записник: http://localhost:' + PORT)
  );
}).catch(e => {
  console.error('DB init failed:', e.message);
  process.exit(1);
});
