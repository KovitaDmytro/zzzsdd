const db = require('../db/database');

const PHONE_RE = /^[+\d][\d\s\-().]{4,}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateContact({ phones = [], emails = [] }) {
  for (const p of phones) {
    if (p.phone && p.phone.trim() && !PHONE_RE.test(p.phone.trim()))
      throw new Error(`Невірний формат телефону: "${p.phone}"`);
  }
  for (const e of emails) {
    if (e.email && e.email.trim() && !EMAIL_RE.test(e.email.trim()))
      throw new Error(`Невірний формат email: "${e.email}"`);
  }
}

const withMeta = id => {
  const c = db.get('SELECT * FROM contacts WHERE id=?', [id]);
  if (!c) return null;
  c.phones        = db.all('SELECT id,phone,label FROM phones        WHERE contact_id=? ORDER BY id', [id]);
  c.emails        = db.all('SELECT id,email,label FROM emails        WHERE contact_id=? ORDER BY id', [id]);
  c.custom_fields = db.all('SELECT id,field_name,field_value FROM custom_fields WHERE contact_id=? ORDER BY id', [id]);
  c.groups        = db.all('SELECT g.id, g.name FROM groups g JOIN contact_groups cg ON g.id=cg.group_id WHERE cg.contact_id=? ORDER BY g.name', [id]);
  return c;
};

const addStr = rows => rows.map(c => ({
  ...c,
  phones_str: db.all('SELECT phone FROM phones WHERE contact_id=?', [c.id]).map(r=>r.phone).join(', '),
  emails_str: db.all('SELECT email FROM emails WHERE contact_id=?', [c.id]).map(r=>r.email).join(', '),
  groups_str: db.all('SELECT g.name FROM groups g JOIN contact_groups cg ON g.id=cg.group_id WHERE cg.contact_id=?', [c.id]).map(r=>r.name).join(', '),
}));

function findAll() {
  return addStr(db.all('SELECT * FROM contacts ORDER BY lower(last_name),lower(first_name)'));
}

function findByGroup(groupId) {
  const rows = db.all(`
    SELECT c.* FROM contacts c
    JOIN contact_groups cg ON c.id=cg.contact_id
    WHERE cg.group_id=?
    ORDER BY lower(c.last_name), lower(c.first_name)
  `, [groupId]);
  return addStr(rows);
}

function search(q) {
  const lk = '%'+q+'%';
  const ids = db.all(`
    SELECT DISTINCT c.id FROM contacts c
    LEFT JOIN phones p ON p.contact_id=c.id
    LEFT JOIN emails e ON e.contact_id=c.id
    WHERE c.first_name LIKE ? OR c.last_name LIKE ? OR c.nickname LIKE ?
       OR c.company LIKE ? OR c.notes LIKE ? OR p.phone LIKE ? OR e.email LIKE ?
    ORDER BY lower(c.last_name),lower(c.first_name)
  `, [lk,lk,lk,lk,lk,lk,lk]).map(r=>r.id);
  return addStr(ids.map(id => db.get('SELECT * FROM contacts WHERE id=?', [id])));
}

function findById(id) { return withMeta(id); }

// Перевіряє чи номер телефону вже є в іншого контакту
function findDuplicatePhone(phones=[], excludeId=null) {
  for (const p of phones) {
    const phone = (p.phone||'').trim();
    if (!phone) continue;
    const row = db.get(
      'SELECT contact_id FROM phones WHERE trim(phone)=? AND contact_id!=?',
      [phone, Number(excludeId)||0]
    );
    if (row) return phone;
  }
  return null;
}

// Перевіряє чи email вже є в іншого контакту
function findDuplicateEmail(emails=[], excludeId=null) {
  for (const e of emails) {
    const email = (e.email||'').trim().toLowerCase();
    if (!email) continue;
    const row = db.get(
      'SELECT contact_id FROM emails WHERE lower(trim(email))=? AND contact_id!=?',
      [email, Number(excludeId)||0]
    );
    if (row) return e.email.trim();
  }
  return null;
}

function insertRelated(id, phones=[], emails=[], custom_fields=[], groups=[]) {
  phones.filter(p=>p.phone?.trim()).forEach(p=>
    db.run('INSERT INTO phones(contact_id,phone,label) VALUES(?,?,?)', [id, p.phone.trim(), p.label||'mobile']));
  emails.filter(e=>e.email?.trim()).forEach(e=>
    db.run('INSERT INTO emails(contact_id,email,label) VALUES(?,?,?)', [id, e.email.trim(), e.label||'personal']));
  custom_fields.filter(f=>f.field_name?.trim()).forEach(f=>
    db.run('INSERT INTO custom_fields(contact_id,field_name,field_value) VALUES(?,?,?)', [id, f.field_name.trim(), f.field_value||'']));
  (groups||[]).forEach(gid => {
    const g = db.get('SELECT id FROM groups WHERE id=?', [Number(gid)]);
    if (g) db.run('INSERT OR IGNORE INTO contact_groups(contact_id,group_id) VALUES(?,?)', [id, g.id]);
  });
}

function create({ first_name, last_name='', nickname='', company='', birthday='', notes='', phones=[], emails=[], custom_fields=[], groups=[] }) {
  validateContact({ phones, emails });
  const dupPhone = findDuplicatePhone(phones);
  if (dupPhone) throw Object.assign(new Error(`Телефон "${dupPhone}" вже використовується іншим контактом`), { field: 'phone' });
  const dupEmail = findDuplicateEmail(emails);
  if (dupEmail) throw Object.assign(new Error(`Email "${dupEmail}" вже використовується іншим контактом`), { field: 'email' });
  db.run('INSERT INTO contacts(first_name,last_name,nickname,company,birthday,notes) VALUES(?,?,?,?,?,?)',
    [first_name.trim(), last_name.trim(), nickname.trim(), company.trim(), birthday, notes.trim()]);
  const id = db.lid();
  insertRelated(id, phones, emails, custom_fields, groups);
  return findById(id);
}

function update(id, { first_name, last_name='', nickname='', company='', birthday='', notes='', phones=[], emails=[], custom_fields=[], groups=[] }) {
  validateContact({ phones, emails });
  const dupPhone = findDuplicatePhone(phones, id);
  if (dupPhone) throw Object.assign(new Error(`Телефон "${dupPhone}" вже використовується іншим контактом`), { field: 'phone' });
  const dupEmail = findDuplicateEmail(emails, id);
  if (dupEmail) throw Object.assign(new Error(`Email "${dupEmail}" вже використовується іншим контактом`), { field: 'email' });
  db.run('UPDATE contacts SET first_name=?,last_name=?,nickname=?,company=?,birthday=?,notes=? WHERE id=?',
    [first_name.trim(), last_name.trim(), nickname.trim(), company.trim(), birthday, notes.trim(), id]);
  ['phones','emails','custom_fields'].forEach(t => db.run(`DELETE FROM ${t} WHERE contact_id=?`, [id]));
  db.run('DELETE FROM contact_groups WHERE contact_id=?', [id]);
  insertRelated(id, phones, emails, custom_fields, groups);
  return findById(id);
}

function remove(id) {
  ['phones','emails','custom_fields','contact_groups'].forEach(t => db.run(`DELETE FROM ${t} WHERE contact_id=?`, [id]));
  db.run('DELETE FROM contacts WHERE id=?', [id]);
}

// ── Groups CRUD ──────────────────────────────────────────────────────────
function getAllGroups() {
  return db.all(`
    SELECT g.id, g.name,
      (SELECT COUNT(*) FROM contact_groups cg WHERE cg.group_id=g.id) as contact_count
    FROM groups g ORDER BY g.name
  `);
}
function createGroup(name) {
  db.run('INSERT INTO groups(name) VALUES(?)', [name.trim()]);
  return db.get('SELECT * FROM groups WHERE id=last_insert_rowid()');
}
function updateGroup(id, name) {
  db.run('UPDATE groups SET name=? WHERE id=?', [name.trim(), id]);
  return db.get('SELECT * FROM groups WHERE id=?', [id]);
}
function removeGroup(id) {
  db.run('DELETE FROM contact_groups WHERE group_id=?', [id]);
  db.run('DELETE FROM groups WHERE id=?', [id]);
}

module.exports = { findAll, findByGroup, search, findById, findDuplicatePhone, findDuplicateEmail, create, update, remove, getAllGroups, createGroup, updateGroup, removeGroup };
