const path      = require('path');
const fs        = require('fs');
const initSqlJs = require('sql.js');

const DB_FILE = path.join(__dirname, 'contacts.db');
let _db = null;

function save() {
  if (!_db) return;
  fs.writeFileSync(DB_FILE, Buffer.from(_db.export()));
}

async function open() {
  if (_db) return _db;
  const SQL = await initSqlJs();
  _db = fs.existsSync(DB_FILE)
    ? new SQL.Database(fs.readFileSync(DB_FILE))
    : new SQL.Database();
  setInterval(save, 5000);
  ['exit','SIGINT','SIGTERM'].forEach(e => process.on(e, () => { save(); if(e!=='exit') process.exit(); }));
  return _db;
}

// Helpers
function run(sql, p=[])  { _db.run(sql, p); }
function get(sql, p=[])  { const s=_db.prepare(sql); s.bind(p); const r=s.step()?s.getAsObject():null; s.free(); return r; }
function all(sql, p=[])  { const s=_db.prepare(sql); s.bind(p); const r=[]; while(s.step()) r.push(s.getAsObject()); s.free(); return r; }
function lid()           { return get('SELECT last_insert_rowid() as id').id; }

module.exports = { open, save, run, get, all, lid };
