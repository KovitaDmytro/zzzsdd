const Contact  = require('../models/Contact');
const db       = require('../db/database');
const { create: xmlCreate } = require('xmlbuilder2');
const xml2js   = require('xml2js');

// ── CRUD ─────────────────────
exports.getAll = (req, res) => {
  const { group_id } = req.query;
  if (group_id) return res.json(Contact.findByGroup(group_id));
  res.json(Contact.findAll());
};
exports.search = (req, res) => res.json(Contact.search(req.query.q || ''));

exports.getOne = (req, res) => {
  const c = Contact.findById(req.params.id);
  c ? res.json(c) : res.status(404).json({ error: 'Not found' });
};

exports.create = (req, res) => {
  const { first_name = '', last_name = '' } = req.body;
  if (!first_name.trim()) return res.status(400).json({ error: "Ім'я є обов'язковим" });
  if (!last_name.trim())  return res.status(400).json({ error: "Прізвище є обов'язковим" });
  try { res.status(201).json(Contact.create(req.body)); }
  catch(e) {
    const code = e.field ? 409 : 400;
    res.status(code).json({ error: e.message, field: e.field || null });
  }
};

exports.update = (req, res) => {
  if (!req.body.first_name?.trim()) return res.status(400).json({ error: "Ім'я є обов'язковим" });
  if (!req.body.last_name?.trim())  return res.status(400).json({ error: "Прізвище є обов'язковим" });
  try { res.json(Contact.update(req.params.id, req.body)); }
  catch(e) {
    const code = e.field ? 409 : 400;
    res.status(code).json({ error: e.message, field: e.field || null });
  }
};

exports.remove = (req, res) => {
  Contact.remove(req.params.id);
  res.json({ ok: true });
};

// ── GROUPS ────────────────────────────────────────
exports.getGroups  = (_req, res) => res.json(Contact.getAllGroups());

exports.createGroup = (req, res) => {
  const { name } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Назва групи є обов\'язковою' });
  try { res.status(201).json(Contact.createGroup(name)); }
  catch(e) { res.status(409).json({ error: 'Група з такою назвою вже існує' }); }
};

exports.updateGroup = (req, res) => {
  const { name } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Назва групи є обов\'язковою' });
  try { res.json(Contact.updateGroup(req.params.id, name)); }
  catch(e) { res.status(500).json({ error: e.message }); }
};

exports.removeGroup = (req, res) => {
  Contact.removeGroup(req.params.id);
  res.json({ ok: true });
};



// ── BACKUP ────────────────────────────
exports.backup = (_req, res) => {
  const all = Contact.findAll().map(c => Contact.findById(c.id));
  const root = xmlCreate({ version:'1.0', encoding:'UTF-8' })
    .ele('contacts_backup')
    .att('version','2.0')
    .att('exported', new Date().toISOString());
  all.forEach(c => {
    const n = root.ele('contact');
    ['id','first_name','last_name','nickname','company','birthday','notes','created_at']
      .forEach(k => n.ele(k).txt(String(c[k]||'')));
    if (c.phones?.length)        { const p=n.ele('phones');        c.phones.forEach(x=>p.ele('phone').att('label',x.label).txt(x.phone)); }
    if (c.emails?.length)        { const e=n.ele('emails');        c.emails.forEach(x=>e.ele('email').att('label',x.label).txt(x.email)); }
    if (c.custom_fields?.length) { const f=n.ele('custom_fields'); c.custom_fields.forEach(x=>f.ele('field').att('name',x.field_name).txt(x.field_value||'')); }
    if (c.groups?.length)        { const g=n.ele('groups');        c.groups.forEach(x=>g.ele('group').att('id',String(x.id)).txt(x.name)); }
  });
  const ts = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="zapisnyk_backup_${ts}.xml"`);
  res.send(root.end({ prettyPrint: true }));
};

// ── RESTORE ──────────────────────────────────────────
exports.restore = async (req, res) => {
  try {
    const { data, replace } = req.body;
    const parsed = await xml2js.parseStringPromise(data||'', { explicitArray:false, trim:true });
    const raw = parsed?.contacts_backup?.contact || parsed?.contacts?.contact;
    if (!raw) return res.status(400).json({ error: 'Невірний формат резервної копії' });
    const list = Array.isArray(raw) ? raw : [raw];

    if (replace) {
      db.run('DELETE FROM contact_groups');
      db.run('DELETE FROM custom_fields');
      db.run('DELETE FROM emails');
      db.run('DELETE FROM phones');
      db.run('DELETE FROM contacts');
      // also clear groups so they get re-created cleanly
      db.run('DELETE FROM groups');
    }

    const toA = v => !v ? [] : Array.isArray(v) ? v : [v];
    let added = 0, skipped = 0;

    // DEBUG: log raw parsed structure of first contact with groups
    const firstWithGroups = list.find(c => c.groups);
    console.log('[RESTORE DEBUG] firstWithGroups.groups:', JSON.stringify(firstWithGroups?.groups));
    console.log('[RESTORE DEBUG] list[0] keys:', Object.keys(list[0]||{}));

    // Helper: extract and clean group name from xml2js node
    // xml2js: <group id="1">NAME</group> => { _: 'NAME', $: { id: '1' } }
    // xml2js: <group>NAME</group>        => 'NAME' (plain string)
    const parseGroupName = g => {
      const raw = typeof g === 'string' ? g : (g._ || '');
      return raw.replace(/[\s\u00a0\u200b]+/g, ' ').trim();
    };

    // Pass 1 — restore groups, build name->id map
    // NOTE: SQLite lower() does NOT work with Cyrillic/Unicode — we do case-folding in JS
    //       and search by exact trimmed name in SQLite.
    const groupNameToId = new Map();
    list.forEach(c => {
      toA(c.groups?.group).forEach(g => {
        const name = parseGroupName(g);
        if (!name) return;
        const nameLower = name.toLowerCase(); // JS toLowerCase works for Cyrillic
        if (groupNameToId.has(nameLower)) return;
        // Search by exact name (trim handled in SQL) — SQLite lower() breaks on Cyrillic
        let existing = db.get('SELECT id FROM groups WHERE name=trim(?)', [name]);
        if (!existing) {
          db.run('INSERT OR IGNORE INTO groups(name) VALUES(?)', [name]);
          existing = db.get('SELECT id FROM groups WHERE name=trim(?)', [name]);
        }
        if (existing) groupNameToId.set(nameLower, existing.id);
      });
    });

    // Pass 2 — restore contacts with correct group ids
    const debugLog = [];
    list.forEach(c => {
      const fn = (c.first_name||'').trim();
      const ln = (c.last_name||'').trim();
      if (!fn) { skipped++; return; }
      const phones  = toA(c.phones?.phone).map(p=>({ phone: typeof p==='string'?p:p._||'', label: typeof p==='object'?(p.$?.label||'mobile'):'mobile' })).filter(p=>p.phone);
      const emails  = toA(c.emails?.email).map(e=>({ email: typeof e==='string'?e:e._||'', label: typeof e==='object'?(e.$?.label||'personal'):'personal' })).filter(e=>e.email);
      const cf      = toA(c.custom_fields?.field).map(f=>({ field_name: typeof f==='object'?(f.$?.name||''):'', field_value: typeof f==='string'?f:f._||'' })).filter(f=>f.field_name);
      // Use same parseGroupName + lowercase key as Pass 1
      const rawGroups = toA(c.groups?.group);
      const groups  = rawGroups
        .map(g => groupNameToId.get(parseGroupName(g).toLowerCase()))
        .filter(Boolean);
      // Debug: log what we found for each contact with groups
      if (rawGroups.length > 0) {
        debugLog.push({
          contact: fn + ' ' + ln,
          rawGroups: rawGroups.map(g => typeof g === 'string' ? g : JSON.stringify(g)),
          parsedNames: rawGroups.map(g => parseGroupName(g)),
          mapKeys: [...groupNameToId.keys()],
          resolvedIds: groups
        });
      }
      try {
        Contact.create({ first_name:fn, last_name:ln, nickname:c.nickname||'', company:c.company||'', birthday:c.birthday||'', notes:c.notes||'', phones, emails, custom_fields:cf, groups });
        added++;
      } catch(err) {
        skipped++;
        debugLog.push({ contact: fn + ' ' + ln, error: err.message });
      }
    });

    db.save();
    res.json({ added, skipped, total: list.length, groups_restored: groupNameToId.size, debug: debugLog });
  } catch(e) {
    console.error('[RESTORE ERROR]', e.stack || e.message);
    res.status(400).json({ error: 'Помилка відновлення: ' + e.message, stack: e.stack });
  }
};

// ── export helpers ────────────────────────────────────────────────────────
function getList(idsParam) {
  if (idsParam) return idsParam.split(',').map(Number).filter(Boolean).map(id => Contact.findById(id)).filter(Boolean);
  return Contact.findAll().map(c => Contact.findById(c.id));
}

// ── EXPORT XML ────────────────────────────────────────────────────────────
exports.exportXml = (req, res) => {
  const root = xmlCreate({ version:'1.0', encoding:'UTF-8' }).ele('contacts');
  getList(req.query.ids).forEach(c => {
    const n = root.ele('contact');
    ['id','first_name','last_name','nickname','company','birthday','notes'].forEach(k => n.ele(k).txt(String(c[k]||'')));
    if (c.phones?.length)        { const p=n.ele('phones');        c.phones.forEach(x=>p.ele('phone').att('label',x.label).txt(x.phone)); }
    if (c.emails?.length)        { const e=n.ele('emails');        c.emails.forEach(x=>e.ele('email').att('label',x.label).txt(x.email)); }
    if (c.custom_fields?.length) { const f=n.ele('custom_fields'); c.custom_fields.forEach(x=>f.ele('field').att('name',x.field_name).txt(x.field_value||'')); }
  });
  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="contacts.xml"');
  res.send(root.end({ prettyPrint: true }));
};

// ── EXPORT VCF (vCard 3.0 — max compatibility: iOS, Android, Outlook) ────
exports.exportVcf = (req, res) => {
  const vcf = getList(req.query.ids).map(c => {
    const fullName = [c.first_name, c.last_name||''].join(' ').trim();
    const l = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN;CHARSET=UTF-8:${fullName}`,
      `N;CHARSET=UTF-8:${c.last_name||''};${c.first_name};;;`
    ];
    if (c.company)  l.push('ORG;CHARSET=UTF-8:'  + c.company);
    if (c.birthday) l.push('BDAY:' + c.birthday);
    if (c.notes)    l.push('NOTE;CHARSET=UTF-8:' + c.notes.replace(/\n/g, '\\n'));
    (c.phones||[]).forEach(p => {
      const type = (p.label||'mobile').toUpperCase();
      l.push(`TEL;TYPE=${type}:${p.phone}`);
    });
    (c.emails||[]).forEach(e => {
      const type = (e.label||'personal').toUpperCase();
      l.push(`EMAIL;TYPE=${type}:${e.email}`);
    });
    l.push('END:VCARD');
    return l.join('\r\n') + '\r\n';
  }).join('\r\n');

  // Send as UTF-8 buffer explicitly — prevents Node from mangling Cyrillic
  const buf = Buffer.from(vcf, 'utf8');
  res.setHeader('Content-Type', 'text/x-vcard; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="contacts.vcf"');
  res.setHeader('Content-Length', buf.length);
  res.end(buf);
};

// ── IMPORT XML ────────────────────────────────────────────────────────────
exports.importXml = async (req, res) => {
  try {
    const parsed = await xml2js.parseStringPromise(req.body.data||'', { explicitArray:false, trim:true });
    const raw = parsed?.contacts?.contact;
    if (!raw) return res.status(400).json({ error: 'Invalid XML: need <contacts><contact>...' });
    const list = Array.isArray(raw) ? raw : [raw];
    let added = 0, skipped = 0;
    const toA = v => !v ? [] : Array.isArray(v) ? v : [v];
    list.forEach(c => {
      const fn = (c.first_name||'').trim();
      const ln = (c.last_name||'').trim();
      if (!fn) { skipped++; return; }
      const phones = toA(c.phones?.phone).map(p=>({ phone: typeof p==='string'?p:p._||'', label: typeof p==='object'?(p.$?.label||'mobile'):'mobile' })).filter(p=>p.phone);
      const emails = toA(c.emails?.email).map(e=>({ email: typeof e==='string'?e:e._||'', label: typeof e==='object'?(e.$?.label||'personal'):'personal' })).filter(e=>e.email);
      const cf     = toA(c.custom_fields?.field).map(f=>({ field_name: typeof f==='object'?(f.$?.name||''):'', field_value: typeof f==='string'?f:f._||'' })).filter(f=>f.field_name);
      try { Contact.create({ first_name:fn, last_name:ln, nickname:c.nickname||'', company:c.company||'', birthday:c.birthday||'', notes:c.notes||'', phones, emails, custom_fields:cf }); added++; }
      catch(e) { skipped++; }
    });
    res.json({ added, skipped, total: list.length });
  } catch(e) { res.status(400).json({ error: 'XML error: ' + e.message }); }
};

// ── IMPORT VCF ────────────────────────────────────────────────────────────
exports.importVcf = (req, res) => {
  // Unfold vCard lines (RFC 6350: CRLF + space/tab = continuation)
  const unfold = s => s.replace(/\r\n[ \t]/g, '').replace(/\n[ \t]/g, '');
  const cards = unfold(req.body.data||'').split(/BEGIN:VCARD/i).slice(1);
  let added = 0, skipped = 0;
  cards.forEach(card => {
    // Match property with optional parameters: PROP;PARAM=VAL:value
    const get    = re => { const m=card.match(re); return m ? m[1].trim() : ''; };
    const getAll = re => [...card.matchAll(re)].map(m => m[1].trim());

    // Parse FN — handle ;CHARSET=UTF-8 and other params
    const fn_raw = get(/^FN[^:]*:(.+)/im);
    // Parse N — handle ;CHARSET=UTF-8 and other params
    const n_raw  = get(/^N[^:]*:([^\r\n]+)/im).split(';');
    // N: last;first — vCard standard
    const firstFromN = (n_raw[1]||'').trim();
    const lastFromN  = (n_raw[0]||'').trim();
    // FN: "First Last" — fallback
    const parts = (fn_raw||'').trim().split(/\s+/);
    const firstFromFN = parts[0]||'';
    const lastFromFN  = parts.slice(1).join(' ');
    const first = (firstFromN || firstFromFN).trim();
    const last  = (lastFromN  || lastFromFN ).trim();
    if (!first) { skipped++; return; }

    // Parse ORG, BDAY, NOTE — handle params like ;CHARSET=UTF-8
    const company  = get(/^ORG[^:]*:(.+)/im);
    const birthday = get(/^BDAY[^:]*:(.+)/im);
    const notes    = get(/^NOTE[^:]*:(.+)/im).replace(/\\n/g, '\n');

    // Parse TEL with TYPE label
    const phones = [...card.matchAll(/^TEL([^:]*):([^\r\n]+)/gim)].map(m => {
      const params = m[1].toUpperCase();
      const phone  = m[2].trim();
      let label = 'mobile';
      if (params.includes('HOME'))   label = 'home';
      else if (params.includes('WORK'))   label = 'work';
      else if (params.includes('MOBILE')) label = 'mobile';
      return { phone, label };
    });

    // Parse EMAIL with TYPE label
    const emails = [...card.matchAll(/^EMAIL([^:]*):([^\r\n]+)/gim)].map(m => {
      const params = m[1].toUpperCase();
      const email  = m[2].trim();
      let label = 'personal';
      if (params.includes('WORK')) label = 'work';
      return { email, label };
    });

    try { Contact.create({ first_name: first, last_name: last, company, birthday, notes, phones, emails, custom_fields: [] }); added++; }
    catch(e) { skipped++; }
  });
  res.json({ added, skipped, total: cards.length });
};