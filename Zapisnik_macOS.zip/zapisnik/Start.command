#!/bin/bash
# Записник — запуск для macOS
cd "$(dirname "$0")"

# Перевірка Node.js
if ! command -v node &> /dev/null; then
  osascript -e 'display alert "Node.js не знайдено" message "Завантажте та встановіть Node.js з сайту nodejs.org, потім запустіть знову." as critical'
  open "https://nodejs.org"
  exit 1
fi

# Встановлення залежностей (якщо потрібно)
if [ ! -d "backend/node_modules" ]; then
  osascript -e 'display notification "Встановлення залежностей, зачекайте..." with title "Записник"'
  cd backend && npm install --silent && cd ..
fi

# Запуск сервера
node backend/server.js &
SERVER_PID=$!

# Чекаємо поки сервер підніметься
sleep 2

# Відкриваємо браузер
open "http://localhost:3001"

# Тримаємо скрипт живим
wait $SERVER_PID
