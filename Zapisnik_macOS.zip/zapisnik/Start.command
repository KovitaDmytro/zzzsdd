#!/bin/bash

cd "$(dirname "$0")"

echo "🚀 Записник запускається..."

# --- перевірка Node.js ---
if ! command -v node &> /dev/null; then
  echo "❌ Node.js не знайдено"

  if command -v brew &> /dev/null; then
    brew install node
  else
    open "https://nodejs.org"
    exit 1
  fi
fi

# --- backend ---
if [ ! -d "backend/node_modules" ]; then
  echo "📦 встановлення backend..."
  cd backend
  npm install
  cd ..
fi

# --- frontend ---
if [ -f "frontend/package.json" ] && [ ! -d "frontend/node_modules" ]; then
  echo "📦 встановлення frontend..."
  cd frontend
  npm install
  cd ..
fi

# --- запуск backend ---
cd backend
node server.js &
BACK_PID=$!

sleep 2

# --- запуск frontend (якщо є) ---
if [ -f "../frontend/package.json" ]; then
  cd ../frontend
  npm start &
fi

# --- відкриття браузера ---
open "http://localhost:3001"

echo "✅ Записник запущено"

wait $BACK_PID