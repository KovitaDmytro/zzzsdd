#!/bin/bash
cd "$(dirname "$0")"

# Встановлення Node.js якщо немає
if ! command -v node &> /dev/null; then
  echo "Node.js не знайдено. Встановлюємо автоматично..."

  # Встановлення Homebrew якщо потрібно
  if ! command -v brew &> /dev/null; then
    echo "Встановлюю Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  fi

  # Підключення brew
  if [ -d "/opt/homebrew/bin" ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  else
    eval "$(/usr/local/bin/brew shellenv)"
  fi

  # Встановлення Node.js
  brew install node > /dev/null 2>&1

  echo "Node.js встановлено."
fi

# Встановлення залежностей якщо потрібно
if [ ! -d "backend/node_modules" ]; then
  echo "Встановлення залежностей..."
  cd backend && npm install --silent && cd ..
  echo "Готово."
fi

# Запуск сервера
echo "Запуск Записника..."
node backend/server.js &
SERVER_PID=$!

sleep 2

# Відкриття браузера (macOS)
open "http://localhost:3001"

echo "Записник працює на http://localhost:3001"
echo "Натисніть Ctrl+C щоб зупинити."

wait $SERVER_PID