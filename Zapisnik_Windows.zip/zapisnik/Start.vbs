Option Explicit

Dim sh, fs, dir, nodeExe, serverJs
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
dir      = fs.GetParentFolderName(WScript.ScriptFullName)
serverJs = dir & "\backend\server.js"

' ── Node.js ──────────────────────────────────────────────────────
nodeExe = FindNode()
If nodeExe = "" Then
    Dim ans
    ans = MsgBox("Node.js not found." & vbCrLf & vbCrLf & _
                 "Download and install automatically (~30 MB)?", _
                 vbYesNo + vbQuestion, "Zapysnyk")
    If ans = vbNo Then
        sh.Run "https://nodejs.org/en/download", 1, False
        MsgBox "Install Node.js LTS and run Start.vbs again.", vbInformation, "Zapysnyk"
        WScript.Quit
    End If
    Dim nodeInst : nodeInst = sh.ExpandEnvironmentStrings("%TEMP%") & "\node_install.msi"
    sh.Popup "Downloading Node.js (~30 MB)...", 3, "Zapysnyk", 64
    sh.Run "powershell -WindowStyle Hidden -Command ""(New-Object Net.WebClient).DownloadFile('https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi', '" & nodeInst & "')""", 0, True
    If Not fs.FileExists(nodeInst) Then
        MsgBox "Download error. Check your internet connection.", vbCritical, "Zapysnyk" : WScript.Quit
    End If
    sh.Popup "Installing Node.js...", 3, "Zapysnyk", 64
    sh.Run "msiexec /i """ & nodeInst & """ /quiet /norestart", 0, True
    On Error Resume Next : fs.DeleteFile nodeInst : On Error GoTo 0
    WScript.Sleep 3000
    nodeExe = FindNode()
    If nodeExe = "" Then
        MsgBox "Done! Close and run Start.vbs again.", vbInformation, "Zapysnyk"
        WScript.Quit
    End If
End If

' ── Backend npm install ──────────────────────────────────────────
If Not fs.FolderExists(dir & "\backend\node_modules") Then
    sh.Popup "Installing server packages...", 3, "Zapysnyk", 64
    sh.Run "powershell -WindowStyle Hidden -Command ""Set-Location '" & dir & "\backend'; npm install""", 0, True
    If Not fs.FolderExists(dir & "\backend\node_modules") Then
        MsgBox "npm install failed. Check your internet connection.", vbCritical, "Zapysnyk" : WScript.Quit
    End If
End If

' ── Frontend build ───────────────────────────────────────────────
If Not fs.FolderExists(dir & "\frontend\dist") Then
    sh.Popup "Installing frontend packages...", 3, "Zapysnyk", 64
    sh.Run "powershell -WindowStyle Hidden -Command ""Set-Location '" & dir & "\frontend'; npm install""", 0, True
    sh.Popup "Building frontend (~1 min)...", 3, "Zapysnyk", 64
    sh.Run "powershell -WindowStyle Hidden -Command ""Set-Location '" & dir & "\frontend'; npm run build""", 0, True
    If Not fs.FolderExists(dir & "\frontend\dist") Then
        MsgBox "Build failed. Check your internet connection.", vbCritical, "Zapysnyk" : WScript.Quit
    End If
End If

' ── Launch node directly (no cmd wrapper, stays alive) ───────────
sh.CurrentDirectory = dir & "\backend"
sh.Run Chr(34) & nodeExe & Chr(34) & " " & Chr(34) & serverJs & Chr(34), 0, False

' ── Wait until server responds (max 10 sec) ──────────────────────
Dim i, ready : ready = False
For i = 1 To 20
    WScript.Sleep 500
    On Error Resume Next
    Dim xhr : Set xhr = CreateObject("MSXML2.XMLHTTP")
    xhr.Open "GET", "http://localhost:3001", False
    xhr.Send
    If xhr.Status = 200 Then ready = True
    Set xhr = Nothing
    On Error GoTo 0
    If ready Then Exit For
Next

sh.Run "http://localhost:3001", 1, False

Set sh = Nothing : Set fs = Nothing
WScript.Quit

' ── Functions ────────────────────────────────────────────────────
Function FindNode()
    Dim i, p(7)
    On Error Resume Next
    Dim w : Set w = sh.Exec("cmd /c where node 2>nul")
    Dim res : res = Trim(w.StdOut.ReadAll())
    On Error GoTo 0
    If res <> "" Then
        Dim a : a = Split(res, vbCrLf)
        If fs.FileExists(Trim(a(0))) Then FindNode = Trim(a(0)) : Exit Function
    End If
    p(0) = sh.ExpandEnvironmentStrings("%ProgramFiles%")      & "\nodejs\node.exe"
    p(1) = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\nodejs\node.exe"
    p(2) = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")      & "\Programs\nodejs\node.exe"
    p(3) = sh.ExpandEnvironmentStrings("%APPDATA%")           & "\nvm\current\node.exe"
    p(4) = "C:\Program Files\nodejs\node.exe"
    p(5) = "C:\Program Files (x86)\nodejs\node.exe"
    p(6) = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")      & "\nvs\default\node.exe"
    p(7) = sh.ExpandEnvironmentStrings("%NVM_HOME%")          & "\nodejs\node.exe"
    For i = 0 To 7
        If fs.FileExists(p(i)) Then FindNode = p(i) : Exit Function
    Next
    FindNode = ""
End Function