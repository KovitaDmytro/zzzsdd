export default function Toast({ msg }) {
  return (
    <div style={{
      position:'fixed',bottom:28,left:'50%',transform:'translateX(-50%)',
      background:'rgba(10,12,25,0.85)',
      backdropFilter:'blur(24px)',
      WebkitBackdropFilter:'blur(24px)',
      color:'#f0f0f5',
      border:'1px solid rgba(52,211,153,0.25)',
      borderRadius:12,
      padding:'10px 22px',
      fontSize:13,fontWeight:600,
      boxShadow:'0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.06)',
      zIndex:2000,
      animation:'toastIn .25s ease',
      maxWidth:420,textAlign:'center',
      whiteSpace:'nowrap',
    }}>
      {msg}
      <style>{`
        @keyframes toastIn{from{opacity:0;transform:translateX(-50%) translateY(10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
      `}</style>
    </div>
  );
}
