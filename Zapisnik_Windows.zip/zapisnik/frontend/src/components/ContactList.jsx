import { avatarPalette, initials } from '../styles.js';

export default function ContactList({ theme:t, L, contacts, loading, selected, query, onSelect, onDetail, onEdit, onDelete, onNew }) {
  if (loading) return (
    <div style={{display:'flex',flexDirection:'column',gap:6}}>
      {[1,2,3,4,5].map(i=>(
        <div key={i} style={{
          height:58,borderRadius:12,
          background:t.bgCard,
          backdropFilter:'blur(20px)',
          border:`1px solid ${t.glassBorder}`,
          animation:`pulse 1.6s ease ${i*.1}s infinite`,
        }}/>
      ))}
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}`}</style>
    </div>
  );

  if (!contacts.length) return (
    <div style={{textAlign:'center',padding:'80px 0',color:t.textMuted}}>
      <div style={{fontSize:42,marginBottom:14,opacity:.2}}>📭</div>
      <div style={{fontSize:15,fontWeight:700,color:t.textSub,marginBottom:6,letterSpacing:'-.01em'}}>{query?L.noResults:L.emptyTitle}</div>
      <div style={{fontSize:13,marginBottom:24,color:t.textMuted}}>{query?L.noResultsSub(query):L.emptySub}</div>
      {!query && (
        <button onClick={onNew} style={{
          background:t.accentGrad,color:'#fff',border:'none',
          borderRadius:10,padding:'10px 26px',fontWeight:700,cursor:'pointer',fontSize:13,
          boxShadow:`0 4px 16px ${t.accent}33`,
        }}>{L.newContact}</button>
      )}
    </div>
  );

  return (
    <div style={{display:'flex',flexDirection:'column',gap:5}}>
      {contacts.map((c, idx) => {
        const {bg} = avatarPalette(c.first_name);
        const sel  = selected.has(c.id);
        return (
          <div key={c.id} className="contact-row"
            style={{
              display:'flex',alignItems:'center',gap:12,padding:'10px 14px',
              borderRadius:12,
              background: sel ? t.accentSoft : t.bgCard,
              backdropFilter:'blur(20px)',
              WebkitBackdropFilter:'blur(20px)',
              color:t.text,
              border:`1px solid ${sel ? t.accentBorder : t.glassBorder}`,
              transition:'all .15s',
              animationDelay:`${idx*.025}s`,
              position:'relative',
              overflow:'hidden',
            }}>

            {/* Glass shimmer top line */}
            <div style={{position:'absolute',top:0,left:0,right:0,height:1,background:'linear-gradient(90deg,transparent,rgba(255,255,255,0.15),transparent)',pointerEvents:'none'}}/>

            <input type="checkbox" checked={sel} onChange={()=>onSelect(c.id)}
              onClick={e=>e.stopPropagation()}
              style={{width:14,height:14,flexShrink:0,accentColor:t.accent,cursor:'pointer'}}/>

            <div onClick={()=>onDetail(c.id)}
              style={{display:'flex',alignItems:'center',gap:12,flex:1,minWidth:0,cursor:'pointer'}}>
              <div style={{
                width:38,height:38,borderRadius:10,flexShrink:0,
                background:bg,
                display:'flex',alignItems:'center',justifyContent:'center',
                fontWeight:700,fontSize:13,color:'#fff',
                boxShadow:'0 2px 8px rgba(0,0,0,0.25)',
              }}>
                {initials(c)}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontWeight:600,fontSize:14,color:t.text,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                  {c.first_name} {c.last_name||''}
                  {c.nickname&&<span style={{color:t.textMuted,fontWeight:400,fontSize:12,marginLeft:6}}>· {c.nickname}</span>}
                </div>
                <div style={{display:'flex',gap:10,marginTop:2,overflow:'hidden'}}>
                  {c.company    &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap'}}>🏢 {c.company}</span>}
                  {c.phones_str &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap'}}>📞 {c.phones_str.split(',')[0].trim()}</span>}
                  {c.emails_str &&<span style={{fontSize:12,color:t.textMuted,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>✉️ {c.emails_str.split(',')[0].trim()}</span>}
                </div>
              </div>
            </div>

            <div style={{display:'flex',gap:4,flexShrink:0}}>
              {[
                {icon:'👁️', label:'Переглянути', cb:e=>{e.stopPropagation();onDetail(c.id);}, d:false},
                {icon:'✏️', label:'Редагувати',  cb:e=>{e.stopPropagation();onEdit(c);},     d:false},
                {icon:'🗑️', label:'Видалити',    cb:e=>{e.stopPropagation();onDelete(c);},   d:true},
              ].map(({icon,label,cb,d},i)=>(
                <button key={i} onClick={cb} title={label}
                  className={`action-btn${d?' action-btn-danger':''}`}
                  style={{
                    background:'transparent',
                    border:`1px solid ${d?'rgba(248,113,113,0.20)':t.glassBorder}`,
                    borderRadius:7,padding:'5px 9px',cursor:'pointer',fontSize:12,
                    color:d?t.danger:t.textMuted,
                    opacity:.45,
                    transition:'all .15s',
                  }}
                  onMouseEnter={e=>{
                    e.currentTarget.style.background = d ? 'rgba(248,113,113,0.12)' : t.hover;
                    e.currentTarget.style.opacity='1';
                    e.currentTarget.style.borderColor = d ? 'rgba(248,113,113,0.4)' : t.accent;
                  }}
                  onMouseLeave={e=>{
                    e.currentTarget.style.background='transparent';
                    e.currentTarget.style.opacity='.45';
                    e.currentTarget.style.borderColor = d ? 'rgba(248,113,113,0.20)' : t.glassBorder;
                  }}>
                  {icon}
                </button>
              ))}
            </div>
          </div>
        );
      })}
      <style>{`
        .contact-row:hover { background:${t.glassHover} !important; border-color:${t.accent}44 !important; }
        .contact-row:hover .action-btn { opacity: 0.85 !important; }
        @keyframes rowIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
        .contact-row{animation:rowIn .22s ease both;}
      `}</style>
    </div>
  );
}
