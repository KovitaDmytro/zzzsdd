import { avatarPalette, initials } from '../styles.js';

export default function ContactDetail({ theme:t, L, contact:c, onClose, onEdit }) {
  const {bg} = avatarPalette(c.first_name);

  const row = (label, val) => val ? (
    <div key={label} style={{
      display:'grid',gridTemplateColumns:'110px 1fr',gap:10,
      padding:'10px 0',
      borderBottom:`1px solid ${t.glassBorder}`,
    }}>
      <span style={{fontSize:11,color:t.textMuted,fontWeight:700,textTransform:'uppercase',letterSpacing:'.08em',paddingTop:1}}>{label}</span>
      <span style={{fontSize:13,color:t.text,lineHeight:1.7}}>{val}</span>
    </div>
  ) : null;

  return (
    <div style={{
      position:'fixed',inset:0,background:t.overlay,
      display:'flex',alignItems:'flex-start',justifyContent:'flex-end',
      zIndex:500,padding:0,
      backdropFilter:'blur(4px)',
    }} onClick={onClose}>
      <div
        onClick={e=>e.stopPropagation()}
        style={{
          background: t.dark ? 'rgba(10,12,25,0.85)' : 'rgba(255,255,255,0.85)',
          backdropFilter:'blur(40px)',
          WebkitBackdropFilter:'blur(40px)',
          color:t.text,
          width:'100%',maxWidth:420,height:'100%',
          overflowY:'auto',
          boxShadow:t.shadowLg,
          borderLeft:`1px solid ${t.glassBorder}`,
          animation:'slideIn .22s ease',
          display:'flex',flexDirection:'column',
        }}>

        {/* Top shimmer */}
        <div style={{position:'absolute',top:0,left:0,right:0,height:1,background:'linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent)'}}/>

        {/* Header */}
        <div style={{
          padding:'24px 22px 18px',
          borderBottom:`1px solid ${t.glassBorder}`,
          flexShrink:0,
        }}>
          {/* Avatar */}
          <div style={{display:'flex',alignItems:'center',gap:14,marginBottom:16}}>
            <div style={{
              width:52,height:52,borderRadius:14,flexShrink:0,
              background:bg,
              display:'flex',alignItems:'center',justifyContent:'center',
              fontWeight:700,fontSize:18,color:'#fff',
              boxShadow:'0 4px 16px rgba(0,0,0,0.3)',
            }}>
              {initials(c)}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <h2 style={{fontSize:18,fontWeight:700,color:t.text,margin:'0 0 3px',letterSpacing:'-.02em'}}>
                {c.first_name} {c.last_name||''}
              </h2>
              {(c.company||c.nickname)&&
                <div style={{fontSize:12,color:t.textMuted}}>{[c.nickname,c.company].filter(Boolean).join(' · ')}</div>
              }
            </div>
          </div>
          <div style={{display:'flex',gap:8}}>
            <button onClick={onEdit} style={{
              flex:1,background:t.accentGrad,color:'#fff',border:'none',
              borderRadius:9,padding:'9px 16px',fontWeight:700,cursor:'pointer',fontSize:13,
              boxShadow:`0 4px 14px ${t.accent}33`,transition:'opacity .15s',
            }}
            onMouseEnter={e=>e.currentTarget.style.opacity='.85'}
            onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
              {L.edit}
            </button>
            <button onClick={onClose} style={{
              background:'transparent',border:`1px solid ${t.glassBorder}`,
              borderRadius:9,padding:'9px 14px',cursor:'pointer',color:t.textMuted,fontSize:13,
              transition:'all .15s',
            }}
            onMouseEnter={e=>{e.currentTarget.style.background=t.hover;e.currentTarget.style.borderColor=t.accent;}}
            onMouseLeave={e=>{e.currentTarget.style.background='transparent';e.currentTarget.style.borderColor=t.glassBorder;}}>
              ✕
            </button>
          </div>
        </div>

        {/* Body */}
        <div style={{padding:'14px 22px 28px',flex:1}}>
          {row(L.born, c.birthday)}
          {(c.phones?.length > 0) && row(L.phonesLabel, c.phones.map(p=>`${p.phone} (${L[p.label]||p.label})`).join('  ·  '))}
          {(c.emails?.length > 0) && row(L.emailLabel,  c.emails.map(e=>e.email).join('  ·  '))}
          {(c.notes?.trim())       && row(L.notesLabel,  c.notes)}
          {(c.groups?.length > 0)  && row(L.groupsDetail, c.groups.map(g=>g.name).join(', '))}
          {(c.custom_fields||[]).map(f=>row(f.field_name, f.field_value))}
        </div>
      </div>
      <style>{`@keyframes slideIn{from{transform:translateX(100%)}to{transform:translateX(0)}}`}</style>
    </div>
  );
}
