import { useState } from 'react';

export default function Sidebar({
  theme:t, dark, toggleTheme, lang, toggleLang, L,
  count, selected, groups, activeGroup,
  onNew, onExport, onImport, onBackup, onRestore,
  onSelectGroup, onNewGroup, onEditGroup, onDeleteGroup,
}) {
  const [hovGroup, setHovGroup] = useState(null);
  const sel = selected.size > 0 ? ` (${selected.size})` : '';

  const sb  = t.sidebarText;
  const sbm = t.sidebarTextMuted;
  const sba = t.sidebarActive;
  const sbh = t.sidebarHover;

  const NavBtn = ({ icon, label, onClick, danger, active }) => (
    <button onClick={onClick} style={{
      display:'flex', alignItems:'center', gap:9,
      width:'100%', padding:'7px 12px', borderRadius:8,
      background: active ? sba : 'transparent',
      border: active ? `1px solid rgba(52,211,153,0.25)` : '1px solid transparent',
      cursor:'pointer',
      color: danger ? '#fca5a5' : active ? t.sidebarAccent : sb,
      fontSize:13, fontWeight: active ? 600 : 400, textAlign:'left',
      transition:'all .15s',
    }}
    onMouseEnter={e=>{
      if(!active) {
        e.currentTarget.style.background = danger ? 'rgba(248,113,113,0.12)' : sbh;
        e.currentTarget.style.borderColor = danger ? 'rgba(248,113,113,0.2)' : 'rgba(255,255,255,0.1)';
      }
    }}
    onMouseLeave={e=>{
      e.currentTarget.style.background = active ? sba : 'transparent';
      e.currentTarget.style.borderColor = active ? 'rgba(52,211,153,0.25)' : 'transparent';
    }}>
      <span style={{width:16,textAlign:'center',flexShrink:0,opacity:.7}}>{icon}</span>
      <span style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{label}</span>
    </button>
  );

  const Divider = () => <div style={{height:'1px',background:t.sidebarBorder,margin:'6px 0'}}/>;
  const SecLabel = ({txt}) => (
    <div style={{fontSize:10,fontWeight:700,color:t.sidebarSection,textTransform:'uppercase',letterSpacing:'.12em',padding:'10px 12px 4px',display:'flex',alignItems:'center',gap:8}}>
      <span style={{flex:1}}>{txt}</span>
    </div>
  );

  return (
    <aside style={{
      width:228, flexShrink:0,
      background: t.sidebar,
      backdropFilter: 'blur(30px)',
      WebkitBackdropFilter: 'blur(30px)',
      display:'flex', flexDirection:'column',
      position:'sticky', top:0, height:'100vh',
      borderRight:`1px solid ${t.sidebarBorder}`,
      overflowY:'auto',
      zIndex: 10,
    }}>

      {/* ── App header ── */}
      <div style={{padding:'18px 14px 14px',borderBottom:`1px solid ${t.sidebarBorder}`}}>
        {/* Logo */}
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
          <div style={{
            width:32,height:32,borderRadius:8,
            background:'linear-gradient(135deg,#34d399,#059669)',
            display:'flex',alignItems:'center',justifyContent:'center',
            fontSize:16,flexShrink:0,
            boxShadow:'0 4px 12px rgba(52,211,153,0.35)',
          }}>📒</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{color:'#f0f0f5',fontSize:14,fontWeight:700,letterSpacing:'-.02em',lineHeight:1.2}}>
              {L.appName}<span style={{color:'#34d399'}}>.</span>
            </div>
            <div style={{color:sbm,fontSize:10,marginTop:1}}>{L.appSub}</div>
          </div>
        </div>

        {/* Theme + Lang controls */}
        <div style={{display:'flex',gap:5,marginBottom:12}}>
          <button onClick={toggleLang} style={{
            flex:1,background:'rgba(255,255,255,0.06)',
            border:'1px solid rgba(255,255,255,0.10)',
            borderRadius:7,padding:'6px',cursor:'pointer',
            color:sb,fontSize:11,fontWeight:700,
            transition:'all .15s',letterSpacing:'.06em',
          }}
          onMouseEnter={e=>{e.currentTarget.style.background='rgba(255,255,255,0.12)';e.currentTarget.style.borderColor='rgba(255,255,255,0.2)';}}
          onMouseLeave={e=>{e.currentTarget.style.background='rgba(255,255,255,0.06)';e.currentTarget.style.borderColor='rgba(255,255,255,0.10)';}}>
            {lang==='ua'?'EN':'UA'}
          </button>
          <button onClick={toggleTheme} style={{
            flex:1,background:'rgba(255,255,255,0.06)',
            border:'1px solid rgba(255,255,255,0.10)',
            borderRadius:7,padding:'6px',cursor:'pointer',
            color:sb,fontSize:13,transition:'all .15s',
          }}
          onMouseEnter={e=>{e.currentTarget.style.background='rgba(255,255,255,0.12)';e.currentTarget.style.borderColor='rgba(255,255,255,0.2)';}}
          onMouseLeave={e=>{e.currentTarget.style.background='rgba(255,255,255,0.06)';e.currentTarget.style.borderColor='rgba(255,255,255,0.10)';}}>
            {dark?'☀️':'🌙'}
          </button>
        </div>

        {/* Contact counter */}
        <div style={{
          padding:'10px 14px',
          background:'rgba(255,255,255,0.04)',
          borderRadius:9,
          border:'1px solid rgba(255,255,255,0.08)',
          display:'flex',alignItems:'baseline',gap:6,
        }}>
          <span style={{fontSize:24,fontWeight:700,color:'#f0f0f5',letterSpacing:'-.04em',lineHeight:1}}>{count}</span>
          <span style={{fontSize:11,color:sbm}}>{L.contactsCount(count).split(' ').slice(1).join(' ')}</span>
        </div>
      </div>

      {/* ── New contact button ── */}
      <div style={{padding:'12px 12px 4px'}}>
        <button onClick={onNew} style={{
          display:'flex',alignItems:'center',justifyContent:'center',gap:7,
          width:'100%',padding:'9px 14px',borderRadius:9,
          background:'linear-gradient(135deg,#34d399,#059669)',
          color:'#fff',border:'none',cursor:'pointer',
          fontSize:13,fontWeight:700,
          boxShadow:'0 4px 16px rgba(52,211,153,0.30)',
          transition:'opacity .15s',
        }}
        onMouseEnter={e=>e.currentTarget.style.opacity='.85'}
        onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
          + {L.newContact.replace('＋ ','')}
        </button>
      </div>

      {/* ── Groups ── */}
      <nav style={{padding:'0 8px',flex:1}}>
        <SecLabel txt={L.groups}/>
        <NavBtn icon="👥" label={L.allGroupsLabel} onClick={()=>onSelectGroup(null)} active={activeGroup===null}/>

        {(groups||[]).map(g => (
          <div key={g.id} style={{position:'relative',display:'flex',alignItems:'center'}}
            onMouseEnter={()=>setHovGroup(g.id)} onMouseLeave={()=>setHovGroup(null)}>
            <button onClick={()=>onSelectGroup(g.id)} style={{
              display:'flex',alignItems:'center',gap:9,flex:1,
              padding:'7px 12px',borderRadius:8,
              border:activeGroup===g.id?'1px solid rgba(52,211,153,0.25)':'1px solid transparent',
              cursor:'pointer',
              background:activeGroup===g.id?sba:'transparent',
              color:activeGroup===g.id?t.sidebarAccent:sb,
              fontSize:13,fontWeight:activeGroup===g.id?600:400,
              textAlign:'left',transition:'all .15s',
            }}
            onMouseEnter={e=>{ if(activeGroup!==g.id){ e.currentTarget.style.background=sbh; e.currentTarget.style.borderColor='rgba(255,255,255,0.1)'; } }}
            onMouseLeave={e=>{ e.currentTarget.style.background=activeGroup===g.id?sba:'transparent'; e.currentTarget.style.borderColor=activeGroup===g.id?'rgba(52,211,153,0.25)':'transparent'; }}>
              <span style={{width:16,textAlign:'center',opacity:.6,flexShrink:0}}>📁</span>
              <span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{g.name}</span>
              <span style={{fontSize:11,color:sbm,marginLeft:4,flexShrink:0}}>{g.contact_count}</span>
            </button>
            {hovGroup===g.id && (
              <div style={{position:'absolute',right:4,display:'flex',gap:2,zIndex:10,background:'rgba(6,6,18,0.9)',backdropFilter:'blur(10px)',borderRadius:6,padding:'2px',border:'1px solid rgba(255,255,255,0.1)'}}>
                <button onClick={e=>{e.stopPropagation();onEditGroup(g);}} style={{background:'rgba(255,255,255,0.08)',border:'none',borderRadius:5,padding:'4px 7px',cursor:'pointer',color:sb,fontSize:11}}>✏️</button>
                <button onClick={e=>{e.stopPropagation();onDeleteGroup(g);}} style={{background:'rgba(248,113,113,0.15)',border:'none',borderRadius:5,padding:'4px 7px',cursor:'pointer',color:'#fca5a5',fontSize:11}}>🗑️</button>
              </div>
            )}
          </div>
        ))}

        <button onClick={onNewGroup} style={{
          display:'flex',alignItems:'center',gap:9,
          width:'100%',padding:'6px 12px',borderRadius:8,
          background:'transparent',
          border:'1px dashed rgba(255,255,255,0.15)',
          cursor:'pointer',color:sbm,fontSize:12,fontWeight:400,marginTop:4,
          transition:'all .15s',
        }}
        onMouseEnter={e=>{e.currentTarget.style.borderColor='rgba(52,211,153,0.4)';e.currentTarget.style.color=t.sidebarAccent;}}
        onMouseLeave={e=>{e.currentTarget.style.borderColor='rgba(255,255,255,0.15)';e.currentTarget.style.color=sbm;}}>
          + {L.newGroup}
        </button>

        <Divider/>

        <div style={{padding:'8px 12px 3px',display:'flex',alignItems:'center'}}>
          <span style={{fontSize:10,fontWeight:700,color:t.sidebarSection,textTransform:'uppercase',letterSpacing:'.12em'}}>{L.export}</span>
        </div>
        <div style={{padding:'2px 10px 6px'}}>
          <div style={{fontSize:10,color:sbm,lineHeight:1.55,background:'rgba(255,255,255,0.04)',borderRadius:6,padding:'5px 8px',border:'1px solid rgba(255,255,255,0.05)'}}>{L.exportNote}</div>
        </div>
        <NavBtn icon="📄" label={'XML' + sel}   onClick={()=>onExport('xml')}/>
        <NavBtn icon="📱" label={'vCard' + sel}  onClick={()=>onExport('vcf')}/>
        <Divider/>
        <SecLabel txt={L.import}/>
        <NavBtn icon="📄" label="XML"   onClick={()=>onImport('xml')}/>
        <NavBtn icon="📱" label="vCard" onClick={()=>onImport('vcf')}/>
      </nav>

      {/* ── Footer tools ── */}
      <div style={{padding:'4px 8px 14px',borderTop:`1px solid ${t.sidebarBorder}`}}>
        <div style={{padding:'6px 10px 4px'}}>
          <div style={{fontSize:10,color:sbm,lineHeight:1.55,background:'rgba(255,255,255,0.03)',borderRadius:6,padding:'5px 8px',border:'1px solid rgba(255,255,255,0.05)'}}>{L.backupNote}</div>
        </div>
        <NavBtn icon="💾" label={L.backup}  onClick={onBackup}/>
        <NavBtn icon="📂" label={L.restore} onClick={onRestore}/>
        <div style={{marginTop:8,padding:'8px 10px',background:'rgba(52,211,153,0.05)',borderRadius:8,border:'1px solid rgba(52,211,153,0.12)'}}>
          <div style={{fontSize:10,color:'rgba(52,211,153,0.6)',lineHeight:1.6,display:'flex',alignItems:'center',gap:5}}>
            <span>🔒</span><span>{L.footer}</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
