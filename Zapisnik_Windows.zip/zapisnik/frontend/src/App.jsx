import { useState, useEffect } from 'react';
import { LIGHT, DARK } from './styles.js';
import { UA, EN } from './i18n.js';
import ContactsPage from './pages/ContactsPage.jsx';

export default function App() {
  const [dark, setDark] = useState(() => {
    try { return localStorage.getItem('ztheme') !== 'light'; } catch { return true; }
  });
  const [lang, setLang] = useState(() => {
    try { return localStorage.getItem('zlang') || 'ua'; } catch { return 'ua'; }
  });

  const toggleTheme = () => setDark(d => {
    const next = !d;
    try { localStorage.setItem('ztheme', next ? 'dark' : 'light'); } catch {}
    return next;
  });
  const toggleLang = () => setLang(l => {
    const next = l === 'ua' ? 'en' : 'ua';
    try { localStorage.setItem('zlang', next); } catch {}
    return next;
  });

  const t = dark ? DARK : LIGHT;
  const L = lang === 'ua' ? UA : EN;

  useEffect(() => {
    document.body.style.cssText = `margin:0;padding:0;background:${t.bg};`;
  }, [dark]);

  return <ContactsPage theme={t} dark={dark} toggleTheme={toggleTheme} L={L} lang={lang} toggleLang={toggleLang} />;
}
