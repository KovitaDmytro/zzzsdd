import { useState, useRef, useEffect } from 'react';
import { useContacts }  from '../hooks/useContacts.js';
import Sidebar          from '../components/Sidebar.jsx';
import ContactList      from '../components/ContactList.jsx';
import ContactForm      from '../components/ContactForm.jsx';
import ContactDetail    from '../components/ContactDetail.jsx';
import Toast            from '../components/Toast.jsx';
import * as api from '../services/api.js';

export default function ContactsPage({ theme:t, dark, toggleTheme, L, lang, toggleLang }) {
  const { contacts, loading, query, setQuery, activeGroup, setActiveGroup, add, edit, del, reload } = useContacts();
  const [form,          setForm]          = useState(null);
  const [detail,        setDetail]        = useState(null);
  const [confirm,       setConfirm]       = useState(null);
  const [selected,      setSelected]      = useState(new Set());
  const [toast,         setToast]         = useState('');
  const [importFmt,     setImportFmt]     = useState(null);
  const [groups,        setGroups]        = useState([]);
  const [groupForm,     setGroupForm]     = useState(null);
  const [groupInput,    setGroupInput]    = useState('');
  const [restoreReplace, setRestoreReplace] = useState(false);

  const fileRef    = useRef();
  const restoreRef = useRef();

  const loadGroups = () => api.getGroups().then(setGroups).catch(()=>{});
  useEffect(() => { loadGroups(); }, []);

  const showToast = msg => { setToast(msg); setTimeout(()=>setToast(''), 3500); };
  const toggleSel = id  => setSelected(s=>{ const n=new Set(s); n.has(id)?n.delete(id):n.add(id); return n; });
  const selAll = () =>
    selected.size === contacts.length
      ? setSelected(new Set())
      : setSelected(new Set(contacts.map(c => c.id)));

  const handleSave = async data => {
    try {
      const isEdit = form && form !== 'new' && form?.id;
      if (isEdit) { await edit(form.id, data); showToast(L.toastUpdated); }
      else        { await add(data);            showToast(L.toastAdded);   }
      setForm(null);
    } catch(e) { throw e; }
  };

  const handleDelete = async () => {
    await del(confirm.data.id);
    setConfirm(null); setDetail(null);
    showToast(L.toastDeleted);
  };

  const handleDeleteSel = async () => {
    const n = selected.size; let failed = 0;
    for (const id of selected) { try { await api.remove(id); } catch { failed++; } }
    setSelected(new Set()); reload(); loadGroups();
    showToast(failed > 0 ? `⚠️ Видалено ${n-failed} з ${n}.` : L.toastDeletedN(n));
  };

  const handleImportClick = fmt => {
    setImportFmt(fmt);
    setTimeout(() => { fileRef.current.accept = fmt==='xml'?'.xml':'.vcf'; fileRef.current.click(); }, 50);
  };
  const handleFileChange = async e => {
    const file = e.target.files[0]; if (!file) return;
    const text = await file.text(); const fmt = importFmt;
    try { const r = await api.importData(fmt, text); reload(); showToast(L.toastImport(fmt.toUpperCase(), r.added, r.skipped)); }
    catch(err) { showToast('❌ '+err.message); }
    e.target.value = ''; setImportFmt(null);
  };

  const handleBackup = () => { api.backup(); showToast(L.toastBackup); };
  const handleRestoreClick = () => { setConfirm({ type:'restore', data:{} }); };
  const handleRestoreConfirm = (replace) => {
    setRestoreReplace(replace); setConfirm(null);
    setTimeout(() => restoreRef.current?.click(), 50);
  };
  const handleRestoreFile = async e => {
    const file = e.target.files[0]; if (!file) return;
    const text = await file.text(); const replace = restoreReplace; setRestoreReplace(false);
    try {
      const r = await api.restore(text, replace);
      reload(); loadGroups();
      showToast(L.toastRestored(r.added, r.skipped) + (r.groups_restored>0?` · груп: ${r.groups_restored}`:''));
    } catch(err) { showToast('❌ '+err.message); }
    e.target.value = '';
  };

  const handleNewGroup    = () => { setGroupForm('new'); setGroupInput(''); };
  const handleEditGroup   = g  => { setGroupForm(g); setGroupInput(g.name); };
  const handleDeleteGroup = g  => setConfirm({ type:'group', data:g });
  const handleGroupConfirmDelete = async () => {
    await api.removeGroup(confirm.data.id);
    if (activeGroup===confirm.data.id) setActiveGroup(null);
    loadGroups(); setConfirm(null); showToast(L.toastGroupDeleted);
  };
  const handleGroupSave = async () => {
    if (!groupInput.trim()) return;
    try {
      if (groupForm==='new') { await api.createGroup(groupInput); showToast(L.toastGroupAdded); }
      else { await api.updateGroup(groupForm.id, groupInput); showToast(L.toastGroupUpdated); }
      loadGroups(); setGroupForm(null);
    } catch(e) { showToast('❌ '+e.message); }
  };

  // ── Glass card style helper ───────────────────────────────────────
  const glassCard = (extra={}) => ({
    background: t.bgCard,
    backdropFilter: 'blur(28px)',
    WebkitBackdropFilter: 'blur(28px)',
    border: `1px solid ${t.glassBorder}`,
    ...extra,
  });

  // ── Modal ─────────────────────────────────────────────────────────
  const Modal = ({ icon, title, desc, onCancel, onConfirm, confirmLabel, danger=true, children }) => (
    <div style={{position:'fixed',inset:0,background:t.overlay,display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:16,backdropFilter:'blur(6px)'}}>
      <div style={{...glassCard({borderRadius:16,padding:32,maxWidth:400,width:'100%',textAlign:'center',boxShadow:t.shadowLg,animation:'fin .18s ease'})}}> 
        <div style={{width:52,height:52,borderRadius:12,background:danger?'rgba(248,113,113,0.12)':t.accentSoft,border:`1px solid ${danger?'rgba(248,113,113,0.3)':t.accentBorder}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,margin:'0 auto 16px'}}>{icon}</div>
        <h3 style={{fontSize:16,fontWeight:700,color:t.text,margin:'0 0 8px',letterSpacing:'-.01em'}}>{title}</h3>
        <p style={{fontSize:13,color:t.textMuted,margin:'0 0 20px',lineHeight:1.7}}>{desc}</p>
        {children}
        <div style={{display:'flex',gap:8,justifyContent:'center'}}>
          <button onClick={onCancel} style={{background:'transparent',color:t.textSub,border:`1px solid ${t.glassBorder}`,borderRadius:8,padding:'9px 22px',cursor:'pointer',fontSize:13,fontWeight:500,backdropFilter:'blur(10px)'}}>
            {L.cancel}
          </button>
          <button onClick={onConfirm} style={{background:danger?'linear-gradient(135deg,#dc2626,#b91c1c)':t.accentGrad,color:'#fff',border:'none',borderRadius:8,padding:'9px 24px',fontWeight:700,cursor:'pointer',fontSize:13}}>
            {confirmLabel}
          </button>
        </div>
        <style>{`@keyframes fin{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}`}</style>
      </div>
    </div>
  );

  const RestoreModal = () => {
    const [replace, setReplace] = useState(false);
    return (
      <div style={{position:'fixed',inset:0,background:t.overlay,display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:16,backdropFilter:'blur(6px)'}}>
        <div style={{...glassCard({borderRadius:16,padding:28,maxWidth:400,width:'100%',boxShadow:t.shadowLg,animation:'fin .18s ease'})}}>
          <div style={{width:52,height:52,borderRadius:12,background:t.accentSoft,border:`1px solid ${t.accentBorder}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,marginBottom:16}}>📂</div>
          <h3 style={{fontSize:16,fontWeight:700,color:t.text,margin:'0 0 16px'}}>{L.restoreTitle}</h3>
          <label style={{display:'flex',alignItems:'center',gap:10,cursor:'pointer',marginBottom:20,padding:'10px 14px',borderRadius:10,border:`1px solid ${replace?t.accentBorder:t.glassBorder}`,background:replace?t.accentSoft:t.inpBg,backdropFilter:'blur(10px)',transition:'all .15s'}}>
            <input type="checkbox" checked={replace} onChange={e=>setReplace(e.target.checked)} style={{accentColor:t.accent,width:15,height:15}}/>
            <span style={{fontSize:13,color:t.textSub,fontWeight:500}}>{L.restoreReplaceLabel}</span>
          </label>
          <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
            <button onClick={()=>setConfirm(null)} style={{background:'transparent',color:t.textSub,border:`1px solid ${t.glassBorder}`,borderRadius:8,padding:'8px 18px',cursor:'pointer',fontSize:13}}>{L.cancel}</button>
            <button onClick={()=>handleRestoreConfirm(replace)} style={{background:t.accentGrad,color:'#fff',border:'none',borderRadius:8,padding:'8px 22px',fontWeight:700,cursor:'pointer',fontSize:13}}>{L.restoreBtn}</button>
          </div>
          <style>{`@keyframes fin{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}`}</style>
        </div>
      </div>
    );
  };

  const GroupFormModal = () => (
    <div style={{position:'fixed',inset:0,background:t.overlay,display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:16,backdropFilter:'blur(6px)'}}>
      <div style={{...glassCard({borderRadius:16,padding:24,maxWidth:340,width:'100%',boxShadow:t.shadowLg,animation:'fin .18s ease'})}}>
        <h3 style={{fontSize:16,fontWeight:700,margin:'0 0 18px',color:t.text}}>{groupForm==='new'?L.newGroup:L.editGroup}</h3>
        <label style={{display:'block',fontSize:11,fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'.1em',marginBottom:6}}>{L.groupName}</label>
        <input
          autoFocus value={groupInput} onChange={e=>setGroupInput(e.target.value)}
          onKeyDown={e=>e.key==='Enter'&&handleGroupSave()}
          placeholder={L.groupNamePlaceholder}
          style={{width:'100%',fontFamily:'inherit',fontSize:14,border:`1px solid ${t.inpBorder}`,borderRadius:9,padding:'10px 14px',boxSizing:'border-box',outline:'none',background:t.inpBg,color:t.text,marginBottom:18,backdropFilter:'blur(10px)'}}
        />
        <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
          <button onClick={()=>setGroupForm(null)} style={{background:'transparent',color:t.textSub,border:`1px solid ${t.glassBorder}`,borderRadius:8,padding:'8px 16px',cursor:'pointer',fontSize:13}}>{L.cancel}</button>
          <button onClick={handleGroupSave} style={{background:t.accentGrad,color:'#fff',border:'none',borderRadius:8,padding:'8px 22px',fontWeight:700,cursor:'pointer',fontSize:13}}>{L.save}</button>
        </div>
        <style>{`@keyframes fin{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}`}</style>
      </div>
    </div>
  );

  const currentGroupName = activeGroup ? (groups.find(g=>g.id===activeGroup)?.name||'') : L.allGroupsLabel;

  // Blob background (dark theme only)
  const BlobBg = () => dark ? (
    <div style={{position:'fixed',inset:0,zIndex:0,overflow:'hidden',pointerEvents:'none'}}>
      <div style={{position:'absolute',width:700,height:700,borderRadius:'50%',background:'radial-gradient(circle,#1a4a6e,transparent 70%)',top:-200,left:-150,filter:'blur(80px)',opacity:.55,animation:'drift 20s ease-in-out infinite alternate'}}/>
      <div style={{position:'absolute',width:600,height:600,borderRadius:'50%',background:'radial-gradient(circle,#2d1b5e,transparent 70%)',top:'10%',right:-100,filter:'blur(80px)',opacity:.55,animation:'drift 25s ease-in-out infinite alternate-reverse'}}/>
      <div style={{position:'absolute',width:500,height:500,borderRadius:'50%',background:'radial-gradient(circle,#0d3d2e,transparent 70%)',bottom:'5%',left:'20%',filter:'blur(80px)',opacity:.55,animation:'drift 22s ease-in-out infinite alternate'}}/>
      <div style={{position:'absolute',width:400,height:400,borderRadius:'50%',background:'radial-gradient(circle,#2d1a0e,transparent 70%)',bottom:'20%',right:'10%',filter:'blur(80px)',opacity:.45,animation:'drift 28s ease-in-out infinite alternate-reverse'}}/>
      <style>{`@keyframes drift{from{transform:translate(0,0) scale(1)}to{transform:translate(40px,30px) scale(1.08)}}`}</style>
    </div>
  ) : (
    <div style={{position:'fixed',inset:0,zIndex:0,overflow:'hidden',pointerEvents:'none'}}>
      <div style={{position:'absolute',width:700,height:700,borderRadius:'50%',background:'radial-gradient(circle,#bfdbfe,transparent 70%)',top:-200,left:-100,filter:'blur(80px)',opacity:.6,animation:'drift 20s ease-in-out infinite alternate'}}/>
      <div style={{position:'absolute',width:500,height:500,borderRadius:'50%',background:'radial-gradient(circle,#d1fae5,transparent 70%)',bottom:'5%',right:'5%',filter:'blur(80px)',opacity:.6,animation:'drift 24s ease-in-out infinite alternate-reverse'}}/>
      <style>{`@keyframes drift{from{transform:translate(0,0) scale(1)}to{transform:translate(40px,30px) scale(1.08)}}`}</style>
    </div>
  );

  return (
    <div style={{display:'flex',minHeight:'100vh',fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif",background:t.bgGradient,color:t.text,position:'relative'}}>
      <BlobBg/>
      <Sidebar
        theme={t} dark={dark} toggleTheme={toggleTheme} lang={lang} toggleLang={toggleLang} L={L}
        count={contacts.length} selected={selected}
        groups={groups} activeGroup={activeGroup}
        onNew={()=>setForm('new')}
        onExport={fmt=>api.exportData(fmt,[...selected])}
        onImport={handleImportClick}
        onBackup={handleBackup}
        onRestore={handleRestoreClick}
        onSelectGroup={setActiveGroup}
        onNewGroup={handleNewGroup}
        onEditGroup={handleEditGroup}
        onDeleteGroup={handleDeleteGroup}
      />
      <input ref={fileRef} type="file" style={{display:'none'}} onChange={handleFileChange}/>
      <input ref={restoreRef} type="file" accept=".xml" style={{display:'none'}} onChange={handleRestoreFile}/>

      <main style={{flex:1,display:'flex',flexDirection:'column',minWidth:0,position:'relative',zIndex:1}}>

        {/* ── Header bar ── */}
        <div style={{...glassCard({borderBottom:`1px solid ${t.glassBorder}`,padding:'14px 28px',display:'flex',alignItems:'center',gap:14,flexShrink:0,borderRadius:0,borderTop:'none',borderLeft:'none',borderRight:'none'})}}>
          <div style={{flex:1}}>
            <h1 style={{fontSize:18,fontWeight:700,letterSpacing:'-.02em',margin:0,color:t.text}}>{L.contacts}</h1>
            <p style={{fontSize:12,color:t.textMuted,margin:'2px 0 0'}}>
              {`${L.records(contacts.length)}${activeGroup?` · ${currentGroupName}`:''}${query?` · «${query}»`:''}${selected.size>0?` · ${selected.size} вибрано`:''}`}
            </p>
          </div>
          <button onClick={()=>setForm('new')} style={{
            display:'flex',alignItems:'center',gap:6,
            background:t.accentGrad,color:'#fff',border:'none',
            borderRadius:10,padding:'9px 18px',fontWeight:700,cursor:'pointer',fontSize:13,
            flexShrink:0,boxShadow:`0 4px 16px ${t.accent}33`,
            transition:'opacity .15s',
          }}
          onMouseEnter={e=>e.currentTarget.style.opacity='.85'}
          onMouseLeave={e=>e.currentTarget.style.opacity='1'}>
            <span style={{fontSize:16,lineHeight:1}}>+</span> {L.newContact.replace('＋ ','')}
          </button>
        </div>

        {/* ── Search bar ── */}
        <div style={{padding:'16px 28px 0',display:'flex',gap:8,alignItems:'center'}}>
          <div style={{flex:1,position:'relative',maxWidth:520}}>
            <svg style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',color:t.textMuted,pointerEvents:'none'}} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={L.searchPlaceholder || "Пошук за ім'ям, телефоном, email..."}
              style={{
                fontFamily:'inherit',fontSize:13,
                border:`1px solid ${t.inpBorder}`,
                borderRadius:10,padding:'9px 36px 9px 36px',
                boxSizing:'border-box',outline:'none',
                background:t.inpBg,
                backdropFilter:'blur(20px)',
                WebkitBackdropFilter:'blur(20px)',
                color:t.text,width:'100%',transition:'all .15s',
              }}
              onFocus={e=>{e.target.style.borderColor=t.accent;e.target.style.boxShadow=`0 0 0 3px ${t.accent}22`;}}
              onBlur={e=>{e.target.style.borderColor=t.inpBorder;e.target.style.boxShadow='none';}}
            />
            {query && (
              <button onClick={()=>setQuery('')} style={{position:'absolute',right:10,top:'50%',transform:'translateY(-50%)',background:t.glassBorder,border:'none',borderRadius:5,padding:'2px 7px',cursor:'pointer',fontSize:11,color:t.textMuted}}>✕</button>
            )}
          </div>
          {contacts.length>0&&(
            <button onClick={selAll} style={{
              background:t.bgCard,backdropFilter:'blur(20px)',WebkitBackdropFilter:'blur(20px)',
              color:t.textMuted,border:`1px solid ${t.glassBorder}`,
              borderRadius:10,padding:'9px 16px',fontWeight:500,cursor:'pointer',fontSize:12,whiteSpace:'nowrap',transition:'all .15s',
            }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=t.accent;e.currentTarget.style.color=t.accent;}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=t.glassBorder;e.currentTarget.style.color=t.textMuted;}}>
              {selected.size===contacts.length?L.deselectAll:L.selectAll}
            </button>
          )}
          {selected.size>0&&(
            <button onClick={handleDeleteSel} style={{
              background:'rgba(248,113,113,0.12)',color:t.danger,
              border:`1px solid rgba(248,113,113,0.3)`,
              borderRadius:10,padding:'9px 16px',fontWeight:700,cursor:'pointer',fontSize:12,whiteSpace:'nowrap',
            }}>
              {L.deleteSelected(selected.size)}
            </button>
          )}
        </div>

        <div style={{flex:1,padding:'14px 28px 28px',overflow:'auto'}}>
          <ContactList theme={t} L={L}
            contacts={contacts}
            loading={loading} selected={selected}
            query={query}
            onSelect={toggleSel}
            onDetail={async id=>{try{setDetail(await api.getOne(id));}catch{}}}
            onEdit={async c=>{try{const full=await api.getOne(c.id);setForm(full);}catch{setForm(c);}}}
            onDelete={c=>setConfirm({type:'contact',data:c})}
            onNew={()=>setForm('new')}
          />
        </div>
      </main>

      {detail&&<ContactDetail theme={t} L={L} contact={detail} onClose={()=>setDetail(null)} onEdit={async ()=>{try{const full=await api.getOne(detail.id);setForm(full);}catch{setForm(detail);}setDetail(null);}}/>}
      {form!==null&&<ContactForm theme={t} L={L} contact={form==='new'?null:(form?.id?form:null)} onSave={handleSave} onCancel={()=>setForm(null)} groups={groups}/>}

      {confirm?.type==='contact' &&<Modal icon="🗑️" title={L.deleteTitle} desc={L.deleteForever(`${confirm.data.first_name} ${confirm.data.last_name||''}`)} onCancel={()=>setConfirm(null)} onConfirm={handleDelete} confirmLabel={L.deleteBtn}/>}
      {confirm?.type==='group'   &&<Modal icon="📁" title={L.deleteGroupTitle} desc={L.deleteGroupDesc(confirm.data.name)} onCancel={()=>setConfirm(null)} onConfirm={handleGroupConfirmDelete} confirmLabel={L.deleteBtn}/>}
      {confirm?.type==='restore' &&<RestoreModal/>}
      {groupForm!==null&&<GroupFormModal/>}
      {toast&&<Toast msg={toast}/>}

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
