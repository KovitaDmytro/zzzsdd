#!/bin/bash
cd "$(dirname "$0")"

# Встановлення Node.js якщо немає
if ! command -v node &> /dev/null; then
  echo "Node.js не знайдено. Встановлюємо автоматично..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash - > /dev/null 2>&1
  sudo apt-get install -y nodejs > /dev/null 2>&1
  echo "Node.js встановлено."
fi

# Встановлення залежностей якщо потрібно
if [ ! -d "backend/node_modules" ]; then
  echo "Встановлення залежностей..."
  cd backend && npm install --silent && cd ..
  echo "Готово."
fi

# Запуск сервера
echo "Запуск Записника..."
node backend/server.js &
SERVER_PID=$!

sleep 2

# Відкриття браузера (WSL або звичайний Linux)
if command -v explorer.exe &> /dev/null; then
  explorer.exe "http://localhost:3001"
elif command -v xdg-open &> /dev/null; then
  xdg-open "http://localhost:3001"
fi

echo "Записник працює на http://localhost:3001"
echo "Натисніть Ctrl+C щоб зупинити."

wait $SERVER_PID
